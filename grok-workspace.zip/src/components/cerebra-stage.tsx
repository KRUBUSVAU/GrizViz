import { useEffect, useRef, useState, useSyncExternalStore } from "react";
import { Mic, Play, Square, Upload } from "lucide-react";
import { AudioSession } from "@/lib/cerebra/audio";
import { DEFAULT_PITCH, DEFAULT_YAW, drawBrain } from "@/lib/cerebra/render";
import { clamp } from "@/lib/cerebra/math";
import { IDLE_READOUT, type Readout } from "@/lib/cerebra/types";

const SYSTEMS = [
  {
    key: "pfc",
    name: "Prefrontal cortex",
    hears: "Chord changes. Major warms it, minor cools it.",
    swatch: "bg-pfc",
  },
  {
    key: "limbic",
    name: "Limbic system",
    hears: "Harmonic mood, drifting in a slow color tide.",
    swatch: "bg-limbic",
  },
  {
    key: "dopamine",
    name: "Dopamine",
    hears: "Rising pitch, a quicker tempo, the drop.",
    swatch: "bg-da",
  },
  {
    key: "norepinephrine",
    name: "Norepinephrine",
    hears: "Sudden hits and leaps in pitch.",
    swatch: "bg-ne",
  },
  {
    key: "auditory",
    name: "Auditory cortex",
    hears: "Where the melody sits, low notes to high.",
    swatch: "bg-auditory",
  },
  {
    key: "motor",
    name: "Motor and cerebellum",
    hears: "The beat, locked to tempo.",
    swatch: "bg-motor",
  },
  {
    key: "memory",
    name: "Hippocampus",
    hears: "A motif returns, and neurons link.",
    swatch: "bg-memory",
  },
] as const;

interface Bridge {
  readout: Readout;
  listeners: Set<() => void>;
}

function statusLine(readout: Readout): string {
  if (readout.source === "study") return "Listening to the study";
  if (readout.source === "mic") return "Listening through the mic";
  if (readout.source === "file") return readout.fileName || "Playing a track";
  return "At rest";
}

export function CerebraStage() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const sessionRef = useRef<AudioSession | null>(null);
  const bridgeRef = useRef<Bridge | null>(null);
  if (!bridgeRef.current) {
    bridgeRef.current = { readout: IDLE_READOUT, listeners: new Set() };
  }
  const yawRef = useRef(DEFAULT_YAW);
  const pitchRef = useRef(DEFAULT_PITCH);
  const zoomRef = useRef(1);
  const dragRef = useRef<{ id: number; x: number; y: number } | null>(null);
  const dragDepth = useRef(0);

  const readout = useSyncExternalStore(
    (notify) => {
      const bridge = bridgeRef.current;
      if (!bridge) return () => {};
      bridge.listeners.add(notify);
      return () => bridge.listeners.delete(notify);
    },
    () => bridgeRef.current?.readout ?? IDLE_READOUT,
    () => IDLE_READOUT,
  );

  const [busy, setBusy] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const [volume, setVolume] = useState(0.85);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    const bridge = bridgeRef.current;
    if (!canvas || !bridge) return;

    const session = new AudioSession();
    sessionRef.current = session;
    setVolume(session.getVolume());
    const unsub = session.subscribe(() => {
      bridge.readout = session.getReadout();
      bridge.listeners.forEach((fn) => fn());
    });

    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)");
    let frame = 0;
    let last = performance.now();

    const loop = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      session.tick(dt);
      const showLabels = false;
      drawBrain(canvas, session.drive, {
        yaw: yawRef.current,
        pitch: pitchRef.current,
        zoom: zoomRef.current,
        reducedMotion: reduced.matches,
        showLabels,
      });
      frame = requestAnimationFrame(loop);
    };
    frame = requestAnimationFrame(loop);

    const onWheel = (event: WheelEvent) => {
      event.preventDefault();
      zoomRef.current = clamp(zoomRef.current * Math.exp(-event.deltaY * 0.0011), 0.65, 1.85);
    };
    canvas.addEventListener("wheel", onWheel, { passive: false });

    const onVisibility = () => {
      if (document.visibilityState !== "visible") return;
      const ctx = sessionRef.current;
      if (!ctx) return;
      if (ctx.getReadout().source !== "idle") void ctx.nudge();
    };
    document.addEventListener("visibilitychange", onVisibility);

    const debug = {
      snapshot: () => session.getReadout(),
      drive: () => ({
        dopamine: session.drive.dopamine,
        norepinephrine: session.drive.norepinephrine,
        modeFast: session.drive.modeFast,
        modeSlow: session.drive.modeSlow,
        auditory: session.drive.auditory,
        beat: session.drive.beat,
        memory: session.drive.memory,
        links: session.drive.synapses.length,
        playing: session.drive.playing,
      }),
    };
    window.__cerebra = debug;

    return () => {
      cancelAnimationFrame(frame);
      canvas.removeEventListener("wheel", onWheel);
      document.removeEventListener("visibilitychange", onVisibility);
      unsub();
      session.dispose();
      sessionRef.current = null;
      if (window.__cerebra === debug) delete window.__cerebra;
    };
  }, []);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.code !== "Space") return;
      if (event.target instanceof HTMLInputElement || event.target instanceof HTMLTextAreaElement) return;
      event.preventDefault();
      const session = sessionRef.current;
      if (!session || busy) return;
      if (session.getReadout().source === "idle") void session.startStudy();
      else void session.stop();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [busy]);

  const playing = readout.source !== "idle";

  async function onStudy() {
    const session = sessionRef.current;
    if (!session) return;
    setBusy(true);
    try {
      if (session.getReadout().source === "study") await session.stop();
      else await session.startStudy();
    } finally {
      setBusy(false);
    }
  }

  async function onMic() {
    const session = sessionRef.current;
    if (!session) return;
    setBusy(true);
    try {
      if (session.getReadout().source === "mic") await session.stop();
      else await session.startMic();
    } finally {
      setBusy(false);
    }
  }

  async function onFile(file: File | undefined) {
    const session = sessionRef.current;
    if (!session || !file) return;
    setBusy(true);
    try {
      await session.startFile(file);
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="flex h-dvh flex-col bg-bg text-fg lg:flex-row">
      <section
        className="relative min-h-0 flex-1"
        onDragEnter={(event) => {
          event.preventDefault();
          dragDepth.current += 1;
          setDragOver(true);
        }}
        onDragOver={(event) => event.preventDefault()}
        onDragLeave={() => {
          dragDepth.current -= 1;
          if (dragDepth.current <= 0) {
            dragDepth.current = 0;
            setDragOver(false);
          }
        }}
        onDrop={(event) => {
          event.preventDefault();
          dragDepth.current = 0;
          setDragOver(false);
          const file = event.dataTransfer.files?.[0];
          void onFile(file);
        }}
      >
        <canvas
          ref={canvasRef}
          className="cerebra-view absolute inset-0 h-full w-full"
          aria-hidden="true"
          onPointerDown={(event) => {
            dragRef.current = { id: event.pointerId, x: event.clientX, y: event.clientY };
            event.currentTarget.setPointerCapture(event.pointerId);
          }}
          onPointerMove={(event) => {
            const drag = dragRef.current;
            if (!drag || drag.id !== event.pointerId) return;
            const dx = event.clientX - drag.x;
            const dy = event.clientY - drag.y;
            drag.x = event.clientX;
            drag.y = event.clientY;
            yawRef.current -= dx * 0.006;
            pitchRef.current = clamp(pitchRef.current + dy * 0.0045, -0.35, 1.05);
          }}
          onPointerUp={(event) => {
            if (dragRef.current?.id === event.pointerId) dragRef.current = null;
          }}
          onPointerCancel={() => {
            dragRef.current = null;
          }}
          onDoubleClick={() => {
            yawRef.current = DEFAULT_YAW;
            pitchRef.current = DEFAULT_PITCH;
            zoomRef.current = 1;
          }}
        />
        <header className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between gap-4 p-4 sm:p-6">
          <div>
            <p className="text-xs tracking-widest text-muted uppercase">Audio anatomy</p>
            <h1 className="font-display text-4xl leading-none text-fg sm:text-5xl">Cerebra</h1>
            <p className="mt-2 hidden max-w-xs text-sm text-muted sm:block">Pitch, pulse, and memory, drawn as a brain.</p>
          </div>
          <p className="hidden max-w-56 text-right text-sm text-fg sm:block">{statusLine(readout)}</p>
        </header>
        {dragOver ? (
          <div className="pointer-events-none absolute inset-4 flex items-center justify-center rounded-xl border border-dashed border-accent sm:inset-6">
            <p className="bg-bg px-4 py-2 text-sm text-fg">Drop a recording</p>
          </div>
        ) : null}
      </section>

      <aside className="cerebra-panel flex h-[52dvh] min-h-0 w-full shrink-0 flex-col overflow-hidden border-t border-line bg-surface lg:h-full lg:w-96 lg:border-t-0 lg:border-l">
        <dl className="grid shrink-0 grid-cols-4 gap-2 px-4 pt-4 lg:px-5 lg:pt-6">
          <Stat label="Bpm" value={readout.bpm} />
          <Stat label="Key" value={readout.key} />
          <Stat label="Chord" value={readout.chord} />
          <Stat label="Links" value={String(readout.links)} />
        </dl>

        <ul className="mt-3 flex min-h-0 flex-1 flex-col gap-3 overflow-y-auto px-4 lg:px-5">
          {SYSTEMS.map((system) => {
            const level = readout.levels[system.key];
            return (
              <li key={system.key} className="grid grid-cols-[1fr_auto] items-center gap-3">
                <div className="min-w-0">
                  <p className="flex items-center gap-2 text-sm text-fg">
                    <span className={`size-2 shrink-0 rounded-full ${system.swatch}`} aria-hidden="true" />
                    {system.name}
                  </p>
                  <p className="mt-0.5 text-xs leading-snug text-muted">{system.hears}</p>
                </div>
                <div
                  role="meter"
                  aria-valuemin={0}
                  aria-valuemax={100}
                  aria-valuenow={Math.round(level * 100)}
                  aria-label={`${system.name} activity`}
                  className="h-1 w-14 overflow-hidden rounded-full bg-line"
                >
                  <div
                    className={`h-full origin-left ${system.swatch} motion-reduce:transition-none`}
                    style={{ transform: `scaleX(${Math.max(0.06, level)})` }}
                  />
                </div>
              </li>
            );
          })}
        </ul>

        <div className="mt-3 shrink-0 space-y-3 border-t border-line px-4 pt-3 lg:px-5">
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              className="col-span-2 inline-flex h-12 items-center justify-center gap-2 rounded-xl bg-accent px-4 text-sm text-bg focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent disabled:opacity-50"
              onClick={() => void onStudy()}
              disabled={busy}
              aria-pressed={readout.source === "study"}
            >
              {playing && readout.source === "study" ? (
                <Square className="size-4" aria-hidden="true" />
              ) : (
                <Play className="size-4" aria-hidden="true" />
              )}
              {readout.source === "study" ? "Stop study" : "Play study"}
            </button>
            <button
              type="button"
              className="inline-flex h-12 items-center justify-center gap-2 rounded-xl border border-line bg-bg px-3 text-sm text-fg focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent disabled:opacity-50"
              onClick={() => void onMic()}
              disabled={busy}
              aria-pressed={readout.source === "mic"}
            >
              <Mic className="size-4" aria-hidden="true" />
              {readout.source === "mic" ? "Stop mic" : "Microphone"}
            </button>
            <button
              type="button"
              className="inline-flex h-12 items-center justify-center gap-2 rounded-xl border border-line bg-bg px-3 text-sm text-fg focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent disabled:opacity-50"
              onClick={() => fileRef.current?.click()}
              disabled={busy}
            >
              <Upload className="size-4" aria-hidden="true" />
              Upload
            </button>
            {mounted ? (
              <input
                ref={fileRef}
                className="sr-only"
                type="file"
                accept="audio/*,.mp3,.wav,.ogg,.m4a,.aac,.flac,.webm"
                onChange={(event) => {
                  const file = event.target.files?.[0];
                  event.target.value = "";
                  void onFile(file);
                }}
              />
            ) : null}
          </div>

          {playing && readout.source !== "mic" ? (
            <label className="flex items-center justify-between gap-3 text-xs text-muted">
              Volume
              <input
                className="w-28"
                type="range"
                min={0}
                max={1}
                step={0.01}
                value={volume}
                onChange={(event) => {
                  const next = Number(event.target.value);
                  setVolume(next);
                  sessionRef.current?.setVolume(next);
                }}
              />
            </label>
          ) : null}

          <p className={readout.message ? "text-sm text-limbic" : "text-sm text-muted"}>
            {readout.message ||
              (playing
                ? "Drag the brain to turn it. A repeated phrase grows a new link."
                : "Play the study, open the microphone, or drop a track on the brain.")}
          </p>
          <p className="text-xs text-muted">
            <span className="lg:hidden">Drag to turn. Double-tap to reset.</span>
            <span className="hidden lg:inline">Drag to turn. Scroll to zoom. Double-click to reset. Space plays the study.</span>
          </p>
        </div>
      </aside>
    </main>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="min-w-0">
      <dt className="text-xs tracking-widest text-muted uppercase">{label}</dt>
      <dd className="truncate font-display text-lg leading-tight text-fg" title={value}>
        {value}
      </dd>
    </div>
  );
}

declare global {
  interface Window {
    __cerebra?: {
      snapshot: () => Readout;
      drive: () => Record<string, number | boolean>;
    };
  }
}
