import { ANCHORS } from "@/lib/cerebra/brain";
import { clamp, toward } from "@/lib/cerebra/math";
import {
  IDLE_READOUT,
  type Drive,
  type Levels,
  type Readout,
  type SourceKind,
  type Synapse,
  type SynapseRegion,
} from "@/lib/cerebra/types";

const PC = ["C", "C♯", "D", "E♭", "E", "F", "F♯", "G", "A♭", "A", "B♭", "B"] as const;

const KK_MAJOR = [6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88];
const KK_MINOR = [6.33, 2.68, 3.52, 5.38, 2.6, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17];

type ScoreEvent =
  | { t: number; kind: "chord"; midis: number[]; dur: number; gain: number }
  | { t: number; kind: "note"; midi: number; dur: number; gain: number }
  | { t: number; kind: "hat"; gain: number }
  | { t: number; kind: "kick"; gain: number }
  | { t: number; kind: "riser"; dur: number };

function buildScore(): { events: ScoreEvent[]; duration: number } {
  const events: ScoreEvent[] = [];
  const C = [48, 52, 55, 64];
  const Am = [45, 52, 57, 64];
  const F = [41, 53, 57, 65];
  const G = [43, 50, 55, 59];
  const Cm = [48, 51, 55, 63];
  const Ab = [44, 51, 56, 63];
  const Fm = [41, 53, 56, 65];
  const Bb = [46, 53, 58, 65];

  const section = (opts: {
    start: number;
    bars: number;
    bpm: number;
    chords: number[][];
    motif: number[];
    hat: number;
    chordGain: number;
    noteGain: number;
    kick: number;
  }): number => {
    const beat = 60 / opts.bpm;
    const bar = beat * 4;
    let t = opts.start;
    for (let i = 0; i < opts.bars; i += 1) {
      const chord = opts.chords[i % opts.chords.length];
      events.push({
        t,
        kind: "chord",
        midis: chord,
        dur: bar * 0.94,
        gain: opts.chordGain,
      });
      events.push({ t, kind: "kick", gain: opts.kick });
      for (let b = 0; b < 4; b += 1) {
        events.push({
          t: t + b * beat,
          kind: "hat",
          gain: b === 0 ? opts.hat : opts.hat * 0.58,
        });
      }
      for (let n = 0; n < 8; n += 1) {
        events.push({
          t: t + n * beat * 0.5,
          kind: "note",
          midi: opts.motif[n % opts.motif.length],
          dur: beat * 0.46,
          gain: opts.noteGain,
        });
      }
      t += bar;
    }
    return t;
  };

  let t = 0;
  t = section({
    start: t,
    bars: 4,
    bpm: 96,
    chords: [C, Am, F, G],
    motif: [76, 79, 84, 86],
    hat: 0.08,
    chordGain: 0.015,
    noteGain: 0.1,
    kick: 0.26,
  });
  const riseStart = t;
  t = section({
    start: t,
    bars: 2,
    bpm: 96,
    chords: [C, C],
    motif: [76, 79, 83, 88],
    hat: 0.07,
    chordGain: 0.018,
    noteGain: 0.11,
    kick: 0.2,
  });
  events.push({ t: riseStart + (t - riseStart) - 1.55, kind: "riser", dur: 1.45 });
  t = section({
    start: t,
    bars: 4,
    bpm: 96,
    chords: [Cm, Ab, Fm, Bb],
    motif: [75, 79, 82, 87],
    hat: 0.08,
    chordGain: 0.015,
    noteGain: 0.1,
    kick: 0.24,
  });
  t = section({
    start: t,
    bars: 4,
    bpm: 132,
    chords: [C, Am, F, G],
    motif: [76, 79, 84, 86],
    hat: 0.1,
    chordGain: 0.014,
    noteGain: 0.09,
    kick: 0.32,
  });
  t = section({
    start: t,
    bars: 2,
    bpm: 96,
    chords: [C, C],
    motif: [76, 79, 84, 86],
    hat: 0.055,
    chordGain: 0.02,
    noteGain: 0.08,
    kick: 0.18,
  });

  events.sort((a, b) => a.t - b.t);
  return { events, duration: t };
}

class StudyPlayer {
  readonly output: GainNode;
  private events: ScoreEvent[];
  private duration: number;
  private origin: number;
  private cursor = 0;
  private timer = 0;
  private stopped = false;
  private hat: AudioBuffer;
  private live = new Set<AudioNode>();

  constructor(
    private ctx: AudioContext,
    dest: AudioNode,
  ) {
    this.output = ctx.createGain();
    this.output.gain.value = 0.95;
    this.output.connect(dest);
    const score = buildScore();
    this.events = score.events;
    this.duration = score.duration;
    this.origin = ctx.currentTime + 0.06;
    const len = Math.floor(ctx.sampleRate * 0.028);
    this.hat = ctx.createBuffer(1, len, ctx.sampleRate);
    const data = this.hat.getChannelData(0);
    for (let i = 0; i < len; i += 1) {
      data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (ctx.sampleRate * 0.0035));
    }
    this.pump();
    this.timer = window.setInterval(() => this.pump(), 80);
  }

  private track(stoppable: OscillatorNode | AudioBufferSourceNode, ...extra: AudioNode[]): void {
    this.live.add(stoppable);
    for (const node of extra) this.live.add(node);
    stoppable.onended = () => {
      try {
        stoppable.disconnect();
      } catch {
        /* already gone */
      }
      for (const node of extra) {
        try {
          node.disconnect();
        } catch {
          /* already gone */
        }
        this.live.delete(node);
      }
      this.live.delete(stoppable);
    };
  }

  private tone(
    when: number,
    freq: number,
    dur: number,
    type: OscillatorType,
    peak: number,
    glide?: number,
  ): void {
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const filter = this.ctx.createBiquadFilter();
    osc.type = type;
    osc.frequency.setValueAtTime(Math.max(40, freq), when);
    if (glide) osc.frequency.exponentialRampToValueAtTime(Math.max(40, glide), when + dur);
    filter.type = "lowpass";
    filter.frequency.setValueAtTime(type === "sine" ? 1400 : 2200, when);
    filter.Q.value = 0.4;
    gain.gain.setValueAtTime(0.0001, when);
    gain.gain.exponentialRampToValueAtTime(Math.max(0.0002, peak), when + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, when + Math.max(0.08, dur));
    osc.connect(gain);
    gain.connect(filter);
    filter.connect(this.output);
    osc.start(when);
    osc.stop(when + dur + 0.05);
    this.track(osc, gain, filter);
  }

  private play(ev: ScoreEvent, when: number): void {
    if (when < this.ctx.currentTime - 0.05) return;
    if (ev.kind === "chord") {
      for (const m of ev.midis) this.tone(when, midiHz(m), ev.dur, "sine", ev.gain);
      return;
    }
    if (ev.kind === "note") {
      this.tone(when, midiHz(ev.midi), ev.dur, "triangle", ev.gain);
      return;
    }
    if (ev.kind === "kick") {
      this.tone(when, 150, 0.16, "sine", ev.gain, 52);
      return;
    }
    if (ev.kind === "hat") {
      const src = this.ctx.createBufferSource();
      src.buffer = this.hat;
      const filter = this.ctx.createBiquadFilter();
      filter.type = "highpass";
      filter.frequency.value = 1600;
      const gain = this.ctx.createGain();
      gain.gain.value = ev.gain;
      src.connect(filter);
      filter.connect(gain);
      gain.connect(this.output);
      src.start(when);
      this.track(src, gain, filter);
      return;
    }
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const filter = this.ctx.createBiquadFilter();
    osc.type = "triangle";
    osc.frequency.setValueAtTime(180, when);
    osc.frequency.exponentialRampToValueAtTime(1200, when + ev.dur);
    filter.type = "lowpass";
    filter.frequency.setValueAtTime(500, when);
    filter.frequency.exponentialRampToValueAtTime(2800, when + ev.dur);
    gain.gain.setValueAtTime(0.0001, when);
    gain.gain.exponentialRampToValueAtTime(0.07, when + ev.dur * 0.92);
    gain.gain.exponentialRampToValueAtTime(0.0001, when + ev.dur);
    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.output);
    osc.start(when);
    osc.stop(when + ev.dur + 0.02);
    this.track(osc, gain, filter);
  }

  private pump(): void {
    if (this.stopped) return;
    const horizon = this.ctx.currentTime + 0.4;
    let guard = 0;
    while (guard < 500) {
      guard += 1;
      if (this.cursor >= this.events.length) {
        this.origin += this.duration;
        if (this.origin < this.ctx.currentTime - 0.15) this.origin = this.ctx.currentTime + 0.05;
        this.cursor = 0;
      }
      const ev = this.events[this.cursor];
      const when = this.origin + ev.t;
      if (when > horizon) break;
      this.play(ev, when);
      this.cursor += 1;
    }
  }

  stop(): void {
    this.stopped = true;
    window.clearInterval(this.timer);
    const t = this.ctx.currentTime;
    try {
      this.output.gain.cancelScheduledValues(t);
      this.output.gain.setTargetAtTime(0.0001, t, 0.02);
    } catch {
      /* context closing */
    }
    for (const node of this.live) {
      try {
        if (node instanceof OscillatorNode || node instanceof AudioBufferSourceNode) node.stop(t);
      } catch {
        /* already stopped */
      }
      try {
        node.disconnect();
      } catch {
        /* already disconnected */
      }
    }
    this.live.clear();
    try {
      this.output.disconnect();
    } catch {
      /* already disconnected */
    }
  }
}

function midiHz(m: number): number {
  return 440 * 2 ** ((m - 69) / 12);
}

function pearson(a: ArrayLike<number>, b: ArrayLike<number>): number {
  let ma = 0;
  let mb = 0;
  for (let i = 0; i < 12; i += 1) {
    ma += a[i];
    mb += b[i];
  }
  ma /= 12;
  mb /= 12;
  let num = 0;
  let da = 0;
  let db = 0;
  for (let i = 0; i < 12; i += 1) {
    const xa = a[i] - ma;
    const xb = b[i] - mb;
    num += xa * xb;
    da += xa * xa;
    db += xb * xb;
  }
  return num / Math.sqrt(da * db + 1e-8);
}

function rotateProfile(profile: number[], root: number): number[] {
  const out = new Array<number>(12);
  for (let i = 0; i < 12; i += 1) out[(i + root) % 12] = profile[i];
  return out;
}

function cosine12(a: ArrayLike<number>, b: ArrayLike<number>): number {
  let dot = 0;
  let na = 0;
  let nb = 0;
  for (let i = 0; i < 12; i += 1) {
    dot += a[i] * b[i];
    na += a[i] * a[i];
    nb += b[i] * b[i];
  }
  return dot / Math.sqrt(na * nb + 1e-8);
}

interface Snap {
  chroma: Float32Array;
  energy: number;
  pc: number;
}

const REGIONS: SynapseRegion[] = ["pfc", "temporal", "motor", "limbic", "occipital", "cerebellum"];

function friendlyError(error: unknown): string {
  if (error instanceof DOMException) {
    if (error.name === "NotAllowedError" || error.name === "PermissionDeniedError") {
      return "Microphone blocked. Allow it in the browser bar, or play the study.";
    }
    if (error.name === "NotFoundError") {
      return "No microphone found. Play the study, or upload a recording.";
    }
  }
  return "That audio didn't open. Try a wav or mp3, or play the study.";
}

export class AudioSession {
  drive: Drive = {
    time: 0,
    playing: false,
    dopamine: 0,
    norepinephrine: 0,
    modeFast: 0,
    modeSlow: 0,
    chordFlash: 0,
    tension: 0,
    auditory: 0,
    pitchNorm: 0.5,
    pitchConf: 0,
    beat: 0,
    harmonic: 0,
    memory: 0,
    energy: 0,
    highs: 0,
    bass: 0,
    synapses: [],
  };

  private fileUrl: string | null = null;

  private ctx: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private out: GainNode | null = null;
  private speakers = false;
  private mediaSrc: MediaElementAudioSourceNode | null = null;
  private audioEl: HTMLAudioElement | null = null;
  private micStream: MediaStream | null = null;
  private micGain: GainNode | null = null;
  private study: StudyPlayer | null = null;
  private source: SourceKind = "idle";
  private fileName = "";
  private message = "";
  private volume = 0.85;
  private readout: Readout = IDLE_READOUT;
  private listeners = new Set<() => void>();
  private freq!: Uint8Array<ArrayBuffer>;
  private prevFreq!: Uint8Array<ArrayBuffer>;
  private time!: Float32Array<ArrayBuffer>;
  private fluxRing = new Float32Array(800);
  private fluxWrite = 0;
  private fluxCount = 0;
  private fluxAcc = 0;
  private fluxHist: number[] = [];
  private lastOnset = -10;
  private prevRms = 0;
  private rollRms = 0;
  private daKick = 0;
  private neKick = 0;
  private riseEnv = 0;
  private lastMidi = 0;
  private haveMidi = false;
  private melodyPc = -1;
  private climb = 0;
  private bpm = 0;
  private bpmConf = 0;
  private committedBpm = 0;
  private bpmStreak = 0;
  private bpmCandidate = 0;
  private lastBpmAt = 0;
  private keyName = "—";
  private chordName = "—";
  private chordStreak = 0;
  private chordCandidate = "—";
  private keyStreak = 0;
  private keyCandidate = "—";
  private chroma = new Float32Array(12);
  private prevChroma = new Float32Array(12);
  private haveChroma = false;
  private snaps: Snap[] = [];
  private snapAcc = 0;
  private searchAcc = 0;
  private lastRepeat = -10;
  private synapseId = 1;
  private salience: Record<SynapseRegion, number> = {
    pfc: 0,
    temporal: 0,
    motor: 0,
    limbic: 0,
    occipital: 0,
    cerebellum: 0,
  };
  private publishAcc = 0;
  private simMatch = 0;

  constructor() {
    try {
      const stored = localStorage.getItem("cerebra-volume");
      if (stored != null) {
        const n = Number(stored);
        if (Number.isFinite(n)) this.volume = clamp(n, 0, 1);
      }
    } catch {
      /* private mode */
    }
  }

  subscribe = (fn: () => void): (() => void) => {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  };

  getReadout = (): Readout => this.readout;

  getVolume(): number {
    return this.volume;
  }

  setVolume(v: number): void {
    this.volume = clamp(v, 0, 1);
    if (this.out && this.ctx) this.out.gain.setTargetAtTime(this.volume, this.ctx.currentTime, 0.03);
    try {
      localStorage.setItem("cerebra-volume", String(this.volume));
    } catch {
      /* ignore */
    }
  }

  private publish(force = false): void {
    const levels: Levels = {
      pfc: q(clamp(0.08 + 0.92 * Math.max(this.drive.chordFlash, this.drive.harmonic * 0.85, Math.abs(this.drive.modeFast) * 0.55))),
      limbic: q(clamp(0.08 + 0.92 * Math.max(Math.abs(this.drive.modeSlow), this.drive.tension * 0.85))),
      dopamine: q(this.drive.dopamine),
      norepinephrine: q(this.drive.norepinephrine),
      auditory: q(this.drive.auditory),
      motor: q(Math.max(this.drive.beat, this.drive.bass * 0.75)),
      memory: q(this.drive.memory),
    };
    const next: Readout = {
      bpm: this.bpmConf > 1.55 && this.committedBpm > 0 ? String(Math.round(this.committedBpm)) : "—",
      key: this.keyName,
      chord: this.chordName,
      links: this.drive.synapses.length,
      source: this.source,
      fileName: this.fileName,
      message: this.message,
      levels,
    };
    const prev = this.readout;
    if (
      !force &&
      prev.bpm === next.bpm &&
      prev.key === next.key &&
      prev.chord === next.chord &&
      prev.links === next.links &&
      prev.source === next.source &&
      prev.fileName === next.fileName &&
      prev.message === next.message &&
      prev.levels.pfc === next.levels.pfc &&
      prev.levels.limbic === next.levels.limbic &&
      prev.levels.dopamine === next.levels.dopamine &&
      prev.levels.norepinephrine === next.levels.norepinephrine &&
      prev.levels.auditory === next.levels.auditory &&
      prev.levels.motor === next.levels.motor &&
      prev.levels.memory === next.levels.memory
    ) {
      return;
    }
    this.readout = next;
    for (const fn of this.listeners) fn();
  }

  private setup(): void {
    const ctx = new AudioContext();
    const analyser = ctx.createAnalyser();
    analyser.fftSize = 2048;
    analyser.smoothingTimeConstant = 0.18;
    analyser.minDecibels = -90;
    analyser.maxDecibels = -12;
    const out = ctx.createGain();
    out.gain.value = this.volume;
    this.ctx = ctx;
    this.analyser = analyser;
    this.out = out;
    out.connect(ctx.destination);
    const bins = analyser.frequencyBinCount;
    this.freq = new Uint8Array(bins);
    this.prevFreq = new Uint8Array(bins);
    this.time = new Float32Array(analyser.fftSize);
    this.audioEl = new Audio();
    this.audioEl.loop = true;
    this.audioEl.preload = "auto";
  }

  nudge(): void {
    if (this.ctx && this.ctx.state === "suspended" && this.source !== "idle") void this.ctx.resume();
  }

  private async ensure(): Promise<AudioContext> {
    if (!this.ctx) this.setup();
    const ctx = this.ctx;
    if (!ctx) throw new Error("Audio unavailable");
    if (ctx.state === "suspended") await ctx.resume();
    return ctx;
  }

  private setSpeakers(on: boolean): void {
    if (!this.analyser || !this.out) return;
    if (on === this.speakers) return;
    try {
      this.analyser.disconnect();
    } catch {
      /* not connected */
    }
    if (on) this.analyser.connect(this.out);
    this.speakers = on;
  }

  private halt(): void {
    this.study?.stop();
    this.study = null;
    try {
      this.micGain?.disconnect();
    } catch {
      /* none */
    }
    this.micGain = null;
    if (this.micStream) {
      for (const track of this.micStream.getTracks()) track.stop();
      this.micStream = null;
    }
    try {
      this.mediaSrc?.disconnect();
    } catch {
      /* none */
    }
    if (this.audioEl) {
      this.audioEl.pause();
      this.audioEl.removeAttribute("src");
    }
    if (this.fileUrl) {
      URL.revokeObjectURL(this.fileUrl);
      this.fileUrl = null;
    }
    this.setSpeakers(false);
    this.source = "idle";
    this.fileName = "";
    this.drive.playing = false;
  }

  async stop(): Promise<void> {
    this.halt();
    this.message = "";
    this.publish(true);
  }

  async startStudy(): Promise<void> {
    const ctx = await this.ensure();
    this.halt();
    if (!this.analyser) return;
    this.setSpeakers(true);
    this.study = new StudyPlayer(ctx, this.analyser);
    this.source = "study";
    this.message = "";
    this.drive.playing = true;
    this.publish(true);
  }

  async startMic(): Promise<void> {
    try {
      const ctx = await this.ensure();
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false },
        video: false,
      });
      this.halt();
      if (!this.analyser) return;
      const gain = ctx.createGain();
      gain.gain.value = 1.6;
      const src = ctx.createMediaStreamSource(stream);
      src.connect(gain);
      gain.connect(this.analyser);
      this.micStream = stream;
      this.micGain = gain;
      this.setSpeakers(false);
      this.source = "mic";
      this.message = "";
      this.drive.playing = true;
      this.publish(true);
    } catch (error) {
      this.message = friendlyError(error);
      this.publish(true);
    }
  }

  async startFile(file: File): Promise<void> {
    try {
      const ctx = await this.ensure();
      if (!this.audioEl || !this.analyser) return;
      this.halt();
      const url = URL.createObjectURL(file);
      this.fileUrl = url;
      this.audioEl.src = url;
      if (!this.mediaSrc) this.mediaSrc = ctx.createMediaElementSource(this.audioEl);
      this.mediaSrc.connect(this.analyser);
      this.setSpeakers(true);
      await this.audioEl.play();
      this.source = "file";
      this.fileName = file.name;
      this.message = "";
      this.drive.playing = true;
      this.publish(true);
    } catch (error) {
      this.message = friendlyError(error);
      this.halt();
      this.publish(true);
    }
  }

  tick(dt: number): void {
    const step = clamp(dt, 0, 0.05);
    this.drive.time += step;
    const playing = this.source !== "idle";
    this.drive.playing = playing;

    let rms = 0;
    let bass = 0;
    let mid = 0;
    let highs = 0;
    let flux = 0;
    let hz = 0;
    let conf = 0;

    if (playing && this.analyser && this.ctx) {
      this.analyser.getByteFrequencyData(this.freq);
      this.analyser.getFloatTimeDomainData(this.time);
      const sr = this.ctx.sampleRate;
      const fft = this.analyser.fftSize;
      rms = rmsOf(this.time);
      bass = band(this.freq, sr, fft, 40, 160);
      mid = band(this.freq, sr, fft, 300, 2800);
      highs = band(this.freq, sr, fft, 5000, 14000);
      flux = spectralFlux(this.freq, this.prevFreq);
      this.prevFreq.set(this.freq);
      const pitch = melodyPeak(this.freq, sr, fft);
      hz = pitch.hz;
      conf = pitch.conf;
      this.accumulateFlux(step, flux);
      this.maybeBpm();
      this.chromaFrom(this.freq, sr, fft);
    } else {
      rms = 0;
      this.haveChroma = false;
    }

    const energy = clamp(rms * 4.2);
    this.rollRms = toward(this.rollRms, rms, step, 1.4);
    const dRms = (rms - this.prevRms) / Math.max(step, 1e-3);
    this.prevRms = rms;
    if (dRms > 0.35) this.riseEnv = Math.max(this.riseEnv, clamp(dRms / 6));
    this.riseEnv *= Math.exp(-step / 0.55);

    let semiDelta = 0;
    if (conf > 0.42 && hz > 90 && hz < 2200) {
      const midi = 69 + 12 * Math.log2(hz / 440);
      this.melodyPc = ((Math.round(midi) % 12) + 12) % 12;
      if (this.haveMidi) {
        const jump = midi - this.lastMidi;
        if (Math.abs(jump) <= 11) {
          semiDelta = jump;
          if (jump > 0) this.climb += jump;
        }
      }
      this.lastMidi = midi;
      this.haveMidi = true;
      const norm = clamp((midi - 64) / 30, 0, 1);
      this.drive.pitchNorm = toward(this.drive.pitchNorm, norm, step, 0.08);
      this.drive.pitchConf = toward(this.drive.pitchConf, conf, step, 0.1);
    } else {
      this.melodyPc = -1;
      this.drive.pitchConf = toward(this.drive.pitchConf, 0, step, 0.2);
    }
    this.climb *= Math.exp(-step / 0.45);

    if (semiDelta > 0.7) this.riseEnv = Math.max(this.riseEnv, clamp(semiDelta / 6));
    if (this.climb > 1.5) this.riseEnv = Math.max(this.riseEnv, clamp(this.climb / 7));
    if (Math.abs(semiDelta) >= 5) this.neKick = Math.max(this.neKick, clamp(Math.abs(semiDelta) / 9));

    const onset = this.detectOnset(flux, playing);
    if (onset) {
      this.drive.beat = 1;
      this.lastOnset = this.drive.time;
      this.neKick = Math.max(this.neKick, clamp(flux * 2.2));
      if (bass > 0.42 && rms > this.rollRms * 1.12) this.daKick = Math.max(this.daKick, 0.85);
    } else {
      this.drive.beat *= Math.exp(-step / 0.14);
    }
    if (playing && this.committedBpm > 70 && this.lastOnset > 0) {
      const period = 60 / this.committedBpm;
      const phase = ((this.drive.time - this.lastOnset) % period) / period;
      const predicted = Math.exp(-(phase * phase) / 0.0035);
      this.drive.beat = Math.max(this.drive.beat, predicted * 0.8);
    }

    this.daKick *= Math.exp(-step / 0.48);
    this.neKick *= Math.exp(-step / 0.3);

    const daTarget = clamp(this.riseEnv * 0.85 + this.daKick + (energy > 0.25 ? this.riseEnv * 0.3 : 0));
    this.drive.dopamine = toward(this.drive.dopamine, playing ? daTarget : 0, step, playing ? 0.12 : 0.4);
    const neTarget = clamp(this.neKick + (playing ? energy * 0.08 : 0));
    this.drive.norepinephrine = toward(this.drive.norepinephrine, neTarget, step, 0.08);

    this.updateHarmony(step, playing, energy);
    this.drive.auditory = toward(this.drive.auditory, playing ? clamp(mid) : 0, step, 0.08);
    this.drive.highs = toward(this.drive.highs, playing ? clamp(highs) : 0, step, 0.1);
    this.drive.bass = toward(this.drive.bass, playing ? clamp(bass) : 0, step, 0.08);
    this.drive.energy = toward(this.drive.energy, playing ? energy : 0, step, 0.12);
    this.drive.tension = toward(this.drive.tension, playing ? dissonance(this.chroma) : 0, step, 0.35);

    this.salience.pfc = toward(
      this.salience.pfc,
      Math.max(this.drive.harmonic, this.drive.chordFlash),
      step,
      0.35,
    );
    this.salience.temporal = toward(this.salience.temporal, this.drive.auditory, step, 0.3);
    this.salience.motor = toward(this.salience.motor, Math.max(this.drive.beat, this.drive.bass), step, 0.25);
    this.salience.limbic = toward(
      this.salience.limbic,
      Math.max(this.drive.tension, Math.abs(this.drive.modeFast)),
      step,
      0.4,
    );
    this.salience.occipital = toward(this.salience.occipital, this.drive.highs, step, 0.3);
    this.salience.cerebellum = toward(this.salience.cerebellum, this.drive.beat, step, 0.25);

    this.memoryStep(step, playing);
    this.decaySynapses(step);

    if (!playing) {
      this.drive.chordFlash *= Math.exp(-step / 0.3);
      this.drive.modeFast = toward(this.drive.modeFast, 0, step, 0.6);
      this.drive.modeSlow = toward(this.drive.modeSlow, 0, step, 1.2);
      this.drive.harmonic = toward(this.drive.harmonic, 0, step, 0.4);
      this.drive.memory = toward(this.drive.memory, 0, step, 0.5);
    }

    this.publishAcc += step;
    if (this.publishAcc >= 0.12) {
      this.publishAcc = 0;
      this.publish();
    }
  }

  dispose(): void {
    this.halt();
    void this.ctx?.close();
    this.ctx = null;
  }

  private accumulateFlux(dt: number, flux: number): void {
    this.fluxAcc += dt;
    let n = 0;
    while (this.fluxAcc >= 0.01 && n < 6) {
      this.fluxAcc -= 0.01;
      this.fluxRing[this.fluxWrite] = flux;
      this.fluxWrite = (this.fluxWrite + 1) % this.fluxRing.length;
      this.fluxCount = Math.min(this.fluxRing.length, this.fluxCount + 1);
      n += 1;
    }
  }

  private maybeBpm(): void {
    if (this.drive.time - this.lastBpmAt < 0.28) return;
    if (this.fluxCount < 280) return;
    this.lastBpmAt = this.drive.time;
    const scores = new Float32Array(181);
    let best = 0;
    let bestBpm = 0;
    let sum = 0;
    let tested = 0;
    const n = this.fluxCount;
    for (let bpm = 70; bpm <= 180; bpm += 1) {
      const lag = Math.round((60 / bpm) / 0.01);
      if (lag < 8 || lag >= n - 8) continue;
      let acc = 0;
      let cnt = 0;
      for (let i = 0; i < n - lag; i += 2) {
        const i0 = (this.fluxWrite - n + i + this.fluxRing.length * 4) % this.fluxRing.length;
        const i1 = (i0 + lag) % this.fluxRing.length;
        acc += this.fluxRing[i0] * this.fluxRing[i1];
        cnt += 1;
      }
      const prior = Math.exp(-((bpm - 102) ** 2) / (2 * 38 * 38));
      const score = (acc / Math.max(1, cnt)) * (0.78 + 0.22 * prior);
      scores[bpm] = score;
      sum += score;
      tested += 1;
      if (score > best) {
        best = score;
        bestBpm = bpm;
      }
    }
    if (bestBpm > 145) {
      const half = Math.round(bestBpm / 2);
      if (half >= 70 && scores[half] > best * 0.8) bestBpm = half;
    }
    const mean = sum / Math.max(1, tested);
    const conf = best / (mean + 1e-6);
    this.bpm = bestBpm;
    this.bpmConf = conf;
    if (conf < 1.45) return;
    if (Math.abs(bestBpm - this.bpmCandidate) <= 3) this.bpmStreak += 1;
    else {
      this.bpmCandidate = bestBpm;
      this.bpmStreak = 1;
    }
    if (this.bpmStreak >= 3) {
      if (this.committedBpm > 0 && Math.abs(bestBpm - this.committedBpm) >= 8) {
        this.neKick = 1;
        if (bestBpm > this.committedBpm) this.daKick = Math.max(this.daKick, 0.9);
      }
      this.committedBpm = this.bpmCandidate;
    }
  }

  private detectOnset(flux: number, playing: boolean): boolean {
    if (!playing) return false;
    this.fluxHist.push(flux);
    if (this.fluxHist.length > 48) this.fluxHist.shift();
    let mean = 0;
    for (const v of this.fluxHist) mean += v;
    mean /= this.fluxHist.length;
    let variance = 0;
    for (const v of this.fluxHist) variance += (v - mean) ** 2;
    const std = Math.sqrt(variance / this.fluxHist.length);
    const thresh = mean + std * 1.35 + 0.012;
    if (flux > thresh && this.drive.time - this.lastOnset > 0.16) return true;
    return false;
  }

  private chromaFrom(freq: Uint8Array, sr: number, fft: number): void {
    this.chroma.fill(0);
    const hzPer = sr / fft;
    const n = freq.length;
    for (let i = 2; i < n; i += 1) {
      const f = i * hzPer;
      if (f < 70 || f > 4200) continue;
      const mag = freq[i] / 255;
      if (mag < 0.08) continue;
      const midi = 69 + 12 * Math.log2(f / 440);
      const pc = ((Math.round(midi) % 12) + 12) % 12;
      this.chroma[pc] += mag * mag;
    }
    let sum = 0;
    for (let i = 0; i < 12; i += 1) sum += this.chroma[i];
    if (sum > 0) {
      for (let i = 0; i < 12; i += 1) this.chroma[i] /= sum;
    }
  }

  private updateHarmony(dt: number, playing: boolean, energy: number): void {
    if (!playing || energy < 0.03) {
      this.drive.harmonic *= Math.exp(-dt / 0.4);
      return;
    }
    let delta = 0;
    if (this.haveChroma) delta = 1 - cosine12(this.chroma, this.prevChroma);
    this.prevChroma.set(this.chroma);
    this.haveChroma = true;
    const motion = clamp(delta * 2.4);
    this.drive.harmonic = toward(this.drive.harmonic, motion, dt, 0.2);

    let bestMaj = 0;
    let bestMin = 0;
    let majRoot = 0;
    let minRoot = 0;
    for (let root = 0; root < 12; root += 1) {
      const maj =
        this.chroma[root] +
        this.chroma[(root + 4) % 12] * 0.95 +
        this.chroma[(root + 7) % 12] * 0.85;
      const min =
        this.chroma[root] +
        this.chroma[(root + 3) % 12] * 0.95 +
        this.chroma[(root + 7) % 12] * 0.85;
      if (maj > bestMaj) {
        bestMaj = maj;
        majRoot = root;
      }
      if (min > bestMin) {
        bestMin = min;
        minRoot = root;
      }
    }
    const triadScore = Math.max(bestMaj, bestMin);
    const mode = triadScore < 0.18 ? 0 : (bestMaj - bestMin) / (bestMaj + bestMin + 1e-6);
    this.drive.modeFast = toward(this.drive.modeFast, mode, dt, 0.28);
    this.drive.modeSlow = toward(this.drive.modeSlow, mode, dt, 1.8);

    const chord =
      triadScore < 0.2
        ? "—"
        : bestMaj >= bestMin
          ? `${PC[majRoot]} major`
          : `${PC[minRoot]} minor`;
    if (chord === this.chordCandidate) this.chordStreak += 1;
    else {
      this.chordCandidate = chord;
      this.chordStreak = 1;
    }
    if (this.chordStreak >= 4 && chord !== this.chordName) {
      if (this.chordName !== "—" && chord !== "—") this.drive.chordFlash = 1;
      this.chordName = chord;
    }
    this.drive.chordFlash *= Math.exp(-dt / 0.42);

    let bestKey = -1;
    let bestKeyScore = -Infinity;
    let bestMode: "major" | "minor" = "major";
    for (let root = 0; root < 12; root += 1) {
      const maj = pearson(this.chroma, rotateProfile(KK_MAJOR, root));
      const min = pearson(this.chroma, rotateProfile(KK_MINOR, root));
      if (maj > bestKeyScore) {
        bestKeyScore = maj;
        bestKey = root;
        bestMode = "major";
      }
      if (min > bestKeyScore) {
        bestKeyScore = min;
        bestKey = root;
        bestMode = "minor";
      }
    }
    const key = bestKeyScore < 0.35 || bestKey < 0 ? "—" : `${PC[bestKey]} ${bestMode}`;
    if (key === this.keyCandidate) this.keyStreak += 1;
    else {
      this.keyCandidate = key;
      this.keyStreak = 1;
    }
    if (this.keyStreak >= 10) this.keyName = key;
  }

  private memoryStep(dt: number, playing: boolean): void {
    this.snapAcc += dt;
    if (playing && this.snapAcc >= 0.1) {
      this.snapAcc = 0;
      let energy = 0;
      for (let i = 0; i < 12; i += 1) energy += this.chroma[i];
      this.snaps.push({ chroma: new Float32Array(this.chroma), energy, pc: this.melodyPc });
      if (this.snaps.length > 180) this.snaps.shift();
    }
    this.searchAcc += dt;
    if (!playing || this.searchAcc < 0.22) {
      this.simMatch *= Math.exp(-dt / 1.1);
      this.drive.memory = toward(this.drive.memory, this.simMatch, dt, 0.25);
      return;
    }
    this.searchAcc = 0;
    const win = 12;
    const snaps = this.snaps;
    if (snaps.length < win + 14) {
      this.drive.memory = toward(this.drive.memory, 0, dt, 0.3);
      return;
    }
    const end = snaps.length;
    let best = 0;
    const minLag = 8;
    const maxLag = Math.min(140, end - win - 1);
    for (let lag = minLag; lag <= maxLag; lag += 2) {
      let mel = 0;
      let harm = 0;
      let energy = 0;
      let voiced = 0;
      for (let i = 0; i < win; i += 1) {
        const cur = snaps[end - win + i];
        const past = snaps[end - win - lag + i];
        harm += cosine12(cur.chroma, past.chroma);
        energy += cur.energy;
        if (cur.pc >= 0 && cur.pc === past.pc) {
          mel += 1;
          voiced += 1;
        } else if (cur.pc >= 0 || past.pc >= 0) {
          voiced += 1;
        }
      }
      const sim = Math.max(harm / win, voiced > 4 ? mel / voiced : 0);
      if (energy / win < 0.12) continue;
      if (sim > best) best = sim;
    }
    if (best > 0.78 && this.drive.time - this.lastRepeat > 0.7) {
      this.lastRepeat = this.drive.time;
      this.simMatch = best;
      this.spawnSynapse();
    } else {
      this.simMatch = Math.max(this.simMatch * Math.exp(-dt / 0.8), best > 0.72 ? best * 0.45 : 0);
    }
    this.drive.memory = toward(this.drive.memory, clamp((best - 0.62) / 0.3), dt, 0.2);
  }

  private spawnSynapse(): void {
    let region: SynapseRegion = "temporal";
    let best = 0.15;
    for (const key of REGIONS) {
      if (this.salience[key] > best) {
        best = this.salience[key];
        region = key;
      }
    }
    const recent = this.drive.synapses.find((s) => s.region === region && this.drive.time - s.born < 5);
    if (recent && recent.strength < 0.92) {
      recent.strength = Math.min(1, recent.strength + 0.22);
      recent.born = this.drive.time;
      return;
    }
    const from = ANCHORS.hippocampus;
    const to = ANCHORS[region];
    const seed = Math.random();
    const side = seed > 0.5 ? 1 : -1;
    const syn: Synapse = {
      id: this.synapseId,
      born: this.drive.time,
      strength: 0.58,
      reveal: 0,
      ax: from[0],
      ay: from[1],
      az: from[2] * side,
      bx: to[0] + (seed - 0.5) * 0.05,
      by: to[1] + (seed - 0.5) * 0.05,
      bz: Math.abs(to[2]) * side,
      cx: (from[0] + to[0]) / 2 + (seed - 0.5) * 0.12,
      cy: Math.max(from[1], to[1]) + 0.14 + seed * 0.12,
      cz: ((from[2] + Math.abs(to[2])) / 2) * side + 0.22 * side,
      region,
    };
    this.synapseId += 1;
    this.drive.synapses.push(syn);
    if (this.drive.synapses.length > 18) {
      this.drive.synapses.sort((a, b) => a.strength - b.strength);
      this.drive.synapses.shift();
    }
  }

  private decaySynapses(dt: number): void {
    const list = this.drive.synapses;
    for (let i = list.length - 1; i >= 0; i -= 1) {
      const syn = list[i];
      syn.reveal = clamp((this.drive.time - syn.born) / 0.7, 0, 1);
      const idle = this.drive.time - syn.born;
      if (idle > 6) syn.strength *= Math.exp(-dt / 16);
      if (syn.strength < 0.14) list.splice(i, 1);
    }
  }
}

function q(n: number): number {
  return Math.round(clamp(n, 0, 1) * 32) / 32;
}

function rmsOf(buf: Float32Array): number {
  let s = 0;
  let n = 0;
  for (let i = 0; i < buf.length; i += 8) {
    s += buf[i] * buf[i];
    n += 1;
  }
  return Math.sqrt(s / Math.max(1, n));
}

function band(freq: Uint8Array, sr: number, fft: number, lo: number, hi: number): number {
  const hzPer = sr / fft;
  const i0 = Math.max(0, Math.floor(lo / hzPer));
  const i1 = Math.min(freq.length - 1, Math.ceil(hi / hzPer));
  if (i1 <= i0) return 0;
  let peak = 0;
  let sum = 0;
  for (let i = i0; i <= i1; i += 1) {
    const v = freq[i];
    sum += v;
    if (v > peak) peak = v;
  }
  const mean = sum / (i1 - i0 + 1) / 255;
  return clamp(peak / 255 * 0.82 + mean * 1.5);
}

function spectralFlux(freq: Uint8Array, prev: Uint8Array): number {
  let s = 0;
  for (let i = 1; i < freq.length; i += 2) {
    const d = freq[i] - prev[i];
    if (d > 0) s += d;
  }
  return s / (freq.length * 40);
}

function melodyPeak(freq: Uint8Array, sr: number, fft: number): { hz: number; conf: number } {
  const hzPer = sr / fft;
  const i0 = Math.max(1, Math.floor(300 / hzPer));
  const i1 = Math.min(freq.length - 2, Math.ceil(1800 / hzPer));
  let best = 0;
  let bestI = i0;
  for (let i = i0; i <= i1; i += 1) {
    const m = freq[i];
    if (m > best) {
      best = m;
      bestI = i;
    }
  }
  const conf = best / 255;
  if (conf < 0.18) return { hz: 0, conf: 0 };
  const left = freq[bestI - 1];
  const right = freq[bestI + 1];
  const denom = left - 2 * best + right;
  const shift = denom === 0 ? 0 : (0.5 * (left - right)) / denom;
  return { hz: (bestI + clamp(shift, -0.5, 0.5)) * hzPer, conf };
}

function dissonance(chroma: Float32Array): number {
  let d = 0;
  for (let i = 0; i < 12; i += 1) {
    d += chroma[i] * chroma[(i + 1) % 12];
    d += chroma[i] * chroma[(i + 6) % 12] * 0.7;
  }
  return clamp(d * 8, 0, 1);
}
