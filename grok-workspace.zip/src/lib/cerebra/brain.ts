import { mulberry32 } from "@/lib/cerebra/math";
import type { SynapseRegion } from "@/lib/cerebra/types";

export type Region =
  | "pfc"
  | "motor"
  | "parietal"
  | "occipital"
  | "temporal"
  | "cerebellum"
  | "brainstem"
  | "hippocampus"
  | "amygdala"
  | "nacc"
  | "vta"
  | "lc";

export type TractId =
  | "none"
  | "dopamine"
  | "norepinephrine"
  | "memory"
  | "motor"
  | "callosum";

export interface BrainPoint {
  id: number;
  x: number;
  y: number;
  z: number;
  nx: number;
  ny: number;
  nz: number;
  region: Region;
  tract: TractId;
  /** Position along a pathway, 0–1. */
  u: number;
  phase: number;
  /** 0 sulcus, 1 gyrus crown. */
  fold: number;
  /** 0 deep, 1 pial surface. */
  shell: number;
  /** 0 none, 1 dopamine, 2 norepinephrine. */
  receptor: 0 | 1 | 2;
  hemi: -1 | 0 | 1;
}

interface Shape {
  cx: number;
  cy: number;
  cz: number;
  rx: number;
  ry: number;
  rz: number;
}

export const ANCHORS: Record<SynapseRegion | "hippocampus", [number, number, number]> = {
  hippocampus: [0.08, -0.12, 0.14],
  pfc: [0.58, 0.34, 0.2],
  temporal: [0.3, -0.18, 0.26],
  motor: [0.14, 0.52, 0.22],
  limbic: [0.28, -0.04, 0.12],
  occipital: [-0.58, 0.12, 0.16],
  cerebellum: [-0.42, -0.22, 0.16],
};

const LEFT: Shape[] = [
  { cx: 0.02, cy: 0.2, cz: 0.2, rx: 0.86, ry: 0.5, rz: 0.22 },
  { cx: 0.5, cy: 0.16, cz: 0.18, rx: 0.4, ry: 0.4, rz: 0.2 },
  { cx: -0.05, cy: 0.5, cz: 0.16, rx: 0.46, ry: 0.24, rz: 0.19 },
  { cx: -0.6, cy: 0.12, cz: 0.14, rx: 0.3, ry: 0.28, rz: 0.17 },
  { cx: 0.24, cy: -0.18, cz: 0.22, rx: 0.5, ry: 0.24, rz: 0.17 },
];

const CEREBELLUM_L: Shape[] = [
  { cx: -0.46, cy: -0.2, cz: 0.14, rx: 0.3, ry: 0.21, rz: 0.15 },
  { cx: -0.3, cy: -0.1, cz: 0.1, rx: 0.16, ry: 0.12, rz: 0.11 },
];

const VERMIS: Shape[] = [{ cx: -0.44, cy: -0.16, cz: 0, rx: 0.18, ry: 0.13, rz: 0.07 }];

const STEM: Shape[] = [
  { cx: 0.02, cy: -0.48, cz: 0, rx: 0.1, ry: 0.32, rz: 0.09 },
  { cx: 0.06, cy: -0.36, cz: 0, rx: 0.14, ry: 0.11, rz: 0.11 },
];

function mirror(list: Shape[]): Shape[] {
  return list.map((s) => ({ ...s, cz: -s.cz }));
}

function ellipsoidK(x: number, y: number, z: number, s: Shape): number {
  const dx = (x - s.cx) / s.rx;
  const dy = (y - s.cy) / s.ry;
  const dz = (z - s.cz) / s.rz;
  return Math.hypot(dx, dy, dz);
}

function nearest(x: number, y: number, z: number, shapes: Shape[]): { k: number; s: Shape } {
  let k = Infinity;
  let best = shapes[0];
  for (const s of shapes) {
    const v = ellipsoidK(x, y, z, s);
    if (v < k) {
      k = v;
      best = s;
    }
  }
  return { k, s: best };
}

function outwardNormal(x: number, y: number, z: number, s: Shape): [number, number, number] {
  const dx = (x - s.cx) / (s.rx * s.rx);
  const dy = (y - s.cy) / (s.ry * s.ry);
  const dz = (z - s.cz) / (s.rz * s.rz);
  const m = Math.hypot(dx, dy, dz) || 1;
  return [dx / m, dy / m, dz / m];
}

function gyrus(x: number, y: number, z: number): number {
  const a = Math.sin(x * 11.2 + y * 2.1 + z * 4.2);
  const b = Math.sin(x * 3.6 - y * 12.4 + z * 7.5);
  const c = Math.sin((x + z) * 7.2 + y * 5.4);
  return a * 0.5 + b * 0.34 + c * 0.22;
}

function inCentralSulcus(x: number, y: number, z: number): boolean {
  if (y < 0.02 || y > 0.74 || Math.abs(z) < 0.12) return false;
  const line = 0.1 + (0.52 - y) * 0.32;
  return Math.abs(x - line) < 0.02;
}

function inSylvian(x: number, y: number, z: number): boolean {
  if (x < -0.22 || x > 0.78 || Math.abs(z) < 0.1) return false;
  const line = -0.01 + (0.62 - x) * 0.2;
  return Math.abs(y - line) < 0.022;
}

function cerebrumRegion(x: number, y: number): Region {
  if (y < 0.05 && x > -0.28 && x < 0.78) return "temporal";
  if (x > 0.3 && y > -0.02) return "pfc";
  if (x > -0.02 && x <= 0.34 && y > 0.12) return "motor";
  if (x < -0.4) return "occipital";
  return "parietal";
}

function cortexReceptor(region: Region, shell: number, rng: () => number): 0 | 1 | 2 {
  if (shell < 0.72) return 0;
  if (region === "pfc" && rng() < 0.18) return 1;
  if (rng() < 0.08) return 2;
  return 0;
}

interface Draft {
  x: number;
  y: number;
  z: number;
  nx: number;
  ny: number;
  nz: number;
  region: Region;
  tract: TractId;
  u: number;
  phase: number;
  fold: number;
  shell: number;
  receptor: 0 | 1 | 2;
  hemi: -1 | 0 | 1;
}

function bbox(shapes: Shape[]): [number, number, number, number, number, number] {
  let x0 = Infinity;
  let y0 = Infinity;
  let z0 = Infinity;
  let x1 = -Infinity;
  let y1 = -Infinity;
  let z1 = -Infinity;
  for (const s of shapes) {
    x0 = Math.min(x0, s.cx - s.rx);
    y0 = Math.min(y0, s.cy - s.ry);
    z0 = Math.min(z0, s.cz - s.rz);
    x1 = Math.max(x1, s.cx + s.rx);
    y1 = Math.max(y1, s.cy + s.ry);
    z1 = Math.max(z1, s.cz + s.rz);
  }
  return [x0, y0, z0, x1, y1, z1];
}

function sampleVolume(
  shapes: Shape[],
  target: number,
  seed: number,
  accept: (x: number, y: number, z: number, k: number) => boolean,
  decorate: (x: number, y: number, z: number, k: number, s: Shape, rng: () => number) => Draft | null,
): Draft[] {
  const rng = mulberry32(seed);
  const [x0, y0, z0, x1, y1, z1] = bbox(shapes);
  const out: Draft[] = [];
  let guard = 0;
  const limit = target * 70;
  while (out.length < target && guard < limit) {
    guard += 1;
    const x = x0 + rng() * (x1 - x0);
    const y = y0 + rng() * (y1 - y0);
    const z = z0 + rng() * (z1 - z0);
    const hit = nearest(x, y, z, shapes);
    if (!accept(x, y, z, hit.k)) continue;
    const draft = decorate(x, y, z, hit.k, hit.s, rng);
    if (draft) out.push(draft);
  }
  return out;
}

function quad(a: [number, number, number], c: [number, number, number], b: [number, number, number], n: number): Array<[number, number, number, number]> {
  const pts: Array<[number, number, number, number]> = [];
  for (let i = 0; i < n; i += 1) {
    const t = n === 1 ? 0.5 : i / (n - 1);
    const o = 1 - t;
    pts.push([
      o * o * a[0] + 2 * o * t * c[0] + t * t * b[0],
      o * o * a[1] + 2 * o * t * c[1] + t * t * b[1],
      o * o * a[2] + 2 * o * t * c[2] + t * t * b[2],
      t,
    ]);
  }
  return pts;
}

function tractPoints(
  samples: Array<[number, number, number, number]>,
  tract: TractId,
  region: Region,
  hemi: -1 | 0 | 1,
  jitter: number,
  rng: () => number,
): Draft[] {
  return samples.map(([x, y, z, u]) => ({
    x: x + (rng() - 0.5) * jitter,
    y: y + (rng() - 0.5) * jitter,
    z: z + (rng() - 0.5) * jitter,
    nx: 0,
    ny: 1,
    nz: hemi === 0 ? 0.2 : hemi,
    region,
    tract,
    u,
    phase: rng(),
    fold: 0.85,
    shell: 1,
    receptor: tract === "dopamine" ? 1 : tract === "norepinephrine" ? 2 : 0,
    hemi,
  }));
}

function buildDrafts(): Draft[] {
  const cerebrum = [...LEFT, ...mirror(LEFT)];
  const cerebellum = [...CEREBELLUM_L, ...mirror(CEREBELLUM_L), ...VERMIS];
  const drafts: Draft[] = [];

  const surface = sampleVolume(
    cerebrum,
    8200,
    11,
    (_x, _y, _z, k) => k <= 1 && k >= 0.86,
    (x, y, z, k, s, rng) => {
      if (Math.abs(z) < 0.028 && y > -0.06) return null;
      if (inCentralSulcus(x, y, z) && rng() < 0.82) return null;
      if (inSylvian(x, y, z) && rng() < 0.88) return null;
      const g = gyrus(x, y, z);
      if (g > 0.62 && k > 0.92 && rng() < 0.75) return null;
      const n = outwardNormal(x, y, z, s);
      const push = -g * 0.028;
      const region = cerebrumRegion(x, y);
      const shell = 1 - (1 - k) / 0.14;
      return {
        x: x + n[0] * push,
        y: y + n[1] * push,
        z: z + n[2] * push,
        nx: n[0],
        ny: n[1],
        nz: n[2],
        region,
        tract: "none",
        u: 0,
        phase: rng(),
        fold: Math.max(0, Math.min(1, 0.5 - g * 0.55)),
        shell: Math.max(0, Math.min(1, shell)),
        receptor: cortexReceptor(region, shell, rng),
        hemi: z >= 0 ? 1 : -1,
      };
    },
  );

  const deep = sampleVolume(
    cerebrum,
    1100,
    29,
    (x, y, z, k) => k > 0.42 && k < 0.8 && !(Math.abs(z) < 0.03 && y > 0.05),
    (x, y, z, k, s, rng) => {
      const n = outwardNormal(x, y, z, s);
      return {
        x,
        y,
        z,
        nx: n[0],
        ny: n[1],
        nz: n[2],
        region: cerebrumRegion(x, y),
        tract: "none",
        u: 0,
        phase: rng(),
        fold: 0.45,
        shell: Math.max(0, Math.min(1, (k - 0.42) / 0.5)),
        receptor: 0,
        hemi: z >= 0 ? 1 : -1,
      };
    },
  );

  const cereb = sampleVolume(
    cerebellum,
    1600,
    47,
    (_x, _y, _z, k) => k <= 1 && k >= 0.55,
    (x, y, z, k, s, rng) => {
      const folia = Math.sin(y * 62 + x * 10 + z * 6);
      if (k > 0.82 && folia < -0.15 && rng() < 0.72) return null;
      const n = outwardNormal(x, y, z, s);
      const shell = k > 0.8 ? 1 : 0.45;
      return {
        x,
        y,
        z,
        nx: n[0],
        ny: n[1],
        nz: n[2],
        region: "cerebellum",
        tract: "none",
        u: 0,
        phase: rng(),
        fold: Math.max(0, Math.min(1, 0.5 + folia * 0.5)),
        shell,
        receptor: shell > 0.8 && rng() < 0.06 ? 2 : 0,
        hemi: Math.abs(z) < 0.04 ? 0 : z > 0 ? 1 : -1,
      };
    },
  );

  const stem = sampleVolume(
    STEM,
    420,
    71,
    (_x, _y, _z, k) => k <= 1 && k >= 0.35,
    (x, y, z, k, s, rng) => {
      const n = outwardNormal(x, y, z, s);
      return {
        x,
        y,
        z,
        nx: n[0],
        ny: n[1],
        nz: n[2],
        region: "brainstem",
        tract: "none",
        u: 0,
        phase: rng(),
        fold: 0.6,
        shell: k > 0.75 ? 0.9 : 0.4,
        receptor: 0,
        hemi: 0,
      };
    },
  );

  drafts.push(...surface, ...deep, ...cereb, ...stem);

  const rng = mulberry32(101);
  const nuclei: Array<{
    region: Region;
    c: [number, number, number];
    s: [number, number, number];
    n: number;
    receptor: 0 | 1 | 2;
    both: boolean;
  }> = [
    { region: "amygdala", c: [0.34, -0.06, 0.1], s: [0.055, 0.045, 0.04], n: 70, receptor: 0, both: true },
    { region: "hippocampus", c: [0.06, -0.13, 0.1], s: [0.12, 0.045, 0.04], n: 90, receptor: 0, both: true },
    { region: "nacc", c: [0.38, 0.0, 0.07], s: [0.05, 0.04, 0.035], n: 64, receptor: 1, both: true },
    { region: "vta", c: [0.04, -0.28, 0.0], s: [0.045, 0.04, 0.04], n: 56, receptor: 1, both: false },
    { region: "lc", c: [-0.02, -0.42, 0.0], s: [0.03, 0.028, 0.028], n: 40, receptor: 2, both: false },
  ];

  for (const nuc of nuclei) {
    const sides = nuc.both ? [1, -1] : [0];
    for (const side of sides) {
      for (let i = 0; i < nuc.n; i += 1) {
        const x = nuc.c[0] + (rng() - 0.5) * 2 * nuc.s[0];
        const y = nuc.c[1] + (rng() - 0.5) * 2 * nuc.s[1];
        const z =
          (nuc.both ? nuc.c[2] * side : nuc.c[2]) + (rng() - 0.5) * 2 * nuc.s[2];
        drafts.push({
          x,
          y,
          z,
          nx: 0.1,
          ny: 0.4,
          nz: side === 0 ? 0.2 : side * 0.7,
          region: nuc.region,
          tract: "none",
          u: 0,
          phase: rng(),
          fold: 0.9,
          shell: 1,
          receptor: nuc.receptor,
          hemi: side === 0 ? 0 : side > 0 ? 1 : -1,
        });
      }
    }
  }

  const tractRng = mulberry32(211);
  const addTract = (
    chains: Array<[[number, number, number], [number, number, number], [number, number, number]]>,
    tract: TractId,
    region: Region,
    hemi: -1 | 0 | 1,
    count: number,
  ) => {
    const per = Math.max(8, Math.floor(count / chains.length));
    for (const [a, c, b] of chains) {
      drafts.push(...tractPoints(quad(a, c, b, per), tract, region, hemi, 0.012, tractRng));
    }
  };

  for (const side of [1, -1] as const) {
    const z = (v: number) => v * side;
    addTract(
      [
        [
          [0.04, -0.28, 0.02 * side],
          [0.22, -0.08, z(0.1)],
          [0.38, 0.0, z(0.08)],
        ],
        [
          [0.38, 0.0, z(0.08)],
          [0.5, 0.18, z(0.18)],
          [0.6, 0.36, z(0.18)],
        ],
      ],
      "dopamine",
      "nacc",
      side,
      70,
    );
    addTract(
      [
        [
          [-0.02, -0.42, 0],
          [0.22, 0.05, z(0.16)],
          [0.55, 0.4, z(0.18)],
        ],
        [
          [-0.02, -0.42, 0],
          [0.12, -0.16, z(0.2)],
          [0.32, -0.16, z(0.26)],
        ],
        [
          [-0.02, -0.42, 0],
          [-0.28, -0.05, z(0.14)],
          [-0.55, 0.16, z(0.16)],
        ],
      ],
      "norepinephrine",
      "lc",
      side,
      90,
    );
    addTract(
      [
        [
          [0.32, -0.16, z(0.24)],
          [0.16, -0.08, z(0.16)],
          [0.08, -0.12, z(0.12)],
        ],
        [
          [0.08, -0.12, z(0.12)],
          [0.32, 0.12, z(0.2)],
          [0.56, 0.32, z(0.18)],
        ],
      ],
      "memory",
      "hippocampus",
      side,
      64,
    );
    addTract(
      [
        [
          [0.12, 0.5, z(0.2)],
          [0.08, 0.12, z(0.1)],
          [0.02, -0.4, z(0.04)],
        ],
      ],
      "motor",
      "motor",
      side,
      36,
    );
  }

  const callosum = quad([-0.42, 0.16, 0], [0.02, 0.4, 0], [0.4, 0.14, 0], 80);
  drafts.push(...tractPoints(callosum, "callosum", "parietal", 0, 0.01, tractRng));
  const callosumLow = quad([-0.38, 0.08, 0], [0.02, 0.28, 0], [0.36, 0.06, 0], 50);
  drafts.push(...tractPoints(callosumLow, "callosum", "parietal", 0, 0.012, tractRng));

  return drafts;
}

let cached: BrainPoint[] | null = null;

export function getBrain(): BrainPoint[] {
  if (cached) return cached;
  const drafts = buildDrafts();
  cached = drafts.map((d, id) => ({ ...d, id }));
  return cached;
}

export const LABEL_ANCHORS: Array<{ text: string; at: [number, number, number] }> = [
  { text: "Prefrontal", at: [0.78, 0.28, 0.12] },
  { text: "Limbic", at: [0.36, -0.02, 0.0] },
  { text: "Auditory", at: [0.55, -0.32, 0.18] },
  { text: "Dopamine", at: [0.5, 0.08, 0.0] },
  { text: "Motor", at: [0.02, 0.72, 0.12] },
  { text: "Hippocampus", at: [0.02, -0.28, 0.0] },
];
