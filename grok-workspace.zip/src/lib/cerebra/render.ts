import { LABEL_ANCHORS, getBrain, type BrainPoint, type Region } from "@/lib/cerebra/brain";
import { clamp, hash01, lerp } from "@/lib/cerebra/math";
import type { Drive, Synapse } from "@/lib/cerebra/types";

export const DEFAULT_YAW = -0.62;
export const DEFAULT_PITCH = 0.38;

const LIGHT = normalize(0.22, 0.84, 0.48);

const STONE: RGB = [176, 166, 154];
const MAJOR: RGB = [228, 190, 142];
const MINOR: RGB = [142, 156, 196];
const LIMBIC_MAJOR: RGB = [214, 160, 142];
const LIMBIC_MINOR: RGB = [132, 122, 176];
const ROSE: RGB = [196, 104, 102];
const GOLD: RGB = [228, 176, 74];
const NE: RGB = [142, 214, 206];
const AUD: RGB = [126, 186, 170];
const MOTOR: RGB = [206, 136, 88];
const MEM: RGB = [210, 196, 226];
const OCC: RGB = [176, 164, 204];
const PAPER: RGB = [236, 228, 214];

type RGB = [number, number, number];

interface Stamp {
  x: number;
  y: number;
  depth: number;
  r: number;
  g: number;
  b: number;
  a: number;
  rad: number;
}

export interface View {
  yaw: number;
  pitch: number;
  zoom: number;
  reducedMotion: boolean;
  showLabels: boolean;
}

const pool: Stamp[] = Array.from({ length: 16000 }, () => ({
  x: 0,
  y: 0,
  depth: 0,
  r: 0,
  g: 0,
  b: 0,
  a: 0,
  rad: 0,
}));
const order = new Array<number>(pool.length);

export function drawBrain(
  canvas: HTMLCanvasElement,
  drive: Drive,
  view: View,
): void {
  const cssW = canvas.clientWidth;
  const cssH = canvas.clientHeight;
  if (cssW < 2 || cssH < 2) return;

  const dpr = Math.min(window.devicePixelRatio || 1, 1.6);
  let bw = Math.max(2, Math.floor(cssW * dpr));
  let bh = Math.max(2, Math.floor(cssH * dpr));
  const longest = Math.max(bw, bh);
  if (longest > 1400) {
    const s = 1400 / longest;
    bw = Math.floor(bw * s);
    bh = Math.floor(bh * s);
  }
  if (canvas.width !== bw || canvas.height !== bh) {
    canvas.width = bw;
    canvas.height = bh;
  }

  const ctx = canvas.getContext("2d", { alpha: false, willReadFrequently: true });
  if (!ctx) return;

  const scale = bw / cssW;
  const insetTop = Math.max(108, cssH * 0.2) * scale;
  const insetSide = 18 * scale;
  const insetBottom = 16 * scale;
  const availW = bw - insetSide * 2;
  const availH = bh - insetTop - insetBottom;
  const viewCx = bw / 2;
  const viewCy = insetTop + availH / 2;
  const fit = Math.min(availW * 0.46, availH * 0.5) * view.zoom;

  ctx.setTransform(1, 0, 0, 1, 0, 0);
  const wash = ctx.createRadialGradient(
    viewCx,
    viewCy - availH * 0.06,
    fit * 0.15,
    viewCx,
    viewCy,
    Math.max(bw, bh) * 0.62,
  );
  wash.addColorStop(0, "#17171d");
  wash.addColorStop(0.55, "#101014");
  wash.addColorStop(1, "#09090c");
  ctx.fillStyle = wash;
  ctx.fillRect(0, 0, bw, bh);

  const img = ctx.getImageData(0, 0, bw, bh);
  const data = img.data;
  const points = getBrain();
  let n = 0;

  for (let i = 0; i < points.length; i += 1) {
    const p = points[i];
    const placed = place(p, drive, view.reducedMotion);
    const proj = project(placed.x, placed.y, placed.z, view.yaw, view.pitch);
    const stamp = pool[n];
    if (!stamp) break;
    const look = colorize(p, drive, proj.z);
    stamp.x = viewCx + proj.x * fit;
    stamp.y = viewCy - proj.y * fit;
    stamp.depth = proj.z + (p.tract === "none" ? 0 : 0.08);
    stamp.r = look.r;
    stamp.g = look.g;
    stamp.b = look.b;
    stamp.a = look.a;
    stamp.rad = look.rad * (fit / 300) * proj.p;
    n += 1;
  }

  for (const syn of drive.synapses) {
    n = stampSynapse(syn, n, drive, view, fit, viewCx, viewCy);
  }

  const count = Math.min(n, pool.length);
  for (let i = 0; i < count; i += 1) order[i] = i;
  const slice = order.slice(0, count);
  slice.sort((a, b) => pool[a].depth - pool[b].depth);

  for (let i = 0; i < count; i += 1) {
    const s = pool[slice[i]];
    if (s.a < 0.04 || s.rad < 0.4) continue;
    blot(data, bw, bh, s.x, s.y, s.rad, s.r, s.g, s.b, s.a);
  }

  ctx.putImageData(img, 0, 0);

  if (view.showLabels) {
    drawLabels(ctx, view, fit, viewCx, viewCy, scale);
  }
}

function place(
  p: BrainPoint,
  drive: Drive,
  reduced: boolean,
): { x: number; y: number; z: number } {
  if (reduced) return { x: p.x, y: p.y, z: p.z };
  const limbic = p.region === "pfc" || p.region === "amygdala" || p.region === "hippocampus";
  const amp = limbic ? 0.012 + Math.abs(drive.modeSlow) * 0.008 : 0.0035;
  const speed = limbic ? 0.42 + drive.harmonic * 1.1 : 0.28;
  const wave = Math.sin(drive.time * speed + p.phase * Math.PI * 2);
  const wob = wave * amp * (drive.playing ? 1 : 0.4);
  return {
    x: p.x + p.nx * wob,
    y: p.y + p.ny * wob,
    z: p.z + p.nz * wob,
  };
}

function project(
  x: number,
  y: number,
  z: number,
  yaw: number,
  pitch: number,
): { x: number; y: number; z: number; p: number } {
  const X = x;
  const Y = y - 0.06;
  const Z = z;
  const cy = Math.cos(yaw);
  const sy = Math.sin(yaw);
  const x1 = X * cy + Z * sy;
  const z1 = -X * sy + Z * cy;
  const cp = Math.cos(pitch);
  const sp = Math.sin(pitch);
  const y2 = Y * cp - z1 * sp;
  const z2 = Y * sp + z1 * cp;
  const persp = 2.35 / (2.35 + 0.25 - z2);
  return { x: x1 * persp, y: y2 * persp, z: z2, p: persp };
}

function colorize(p: BrainPoint, drive: Drive, depth: number): { r: number; g: number; b: number; a: number; rad: number } {
  const nd = clamp(p.nx * LIGHT[0] + p.ny * LIGHT[1] + p.nz * LIGHT[2], 0, 1);
  let tone = (0.38 + 0.62 * nd) * (0.4 + 0.6 * p.fold) * (0.68 + 0.32 * p.shell);
  const front = clamp((depth + 0.4) / 1.3, 0, 1);
  tone *= 0.78 + 0.22 * front;

  let hot: RGB = STONE;
  let amt = 0;
  let rad = (p.shell > 0.78 ? 2.15 : 1.35) * (0.78 + 0.35 * p.fold);
  let alpha = 0.78;

  if (p.tract === "dopamine") {
    const head = (drive.time * 0.33) % 1;
    const bolus = Math.exp(-((p.u - head) ** 2) / 0.02) * drive.dopamine;
    amt = clamp(0.22 + drive.dopamine * 0.75 + bolus);
    hot = GOLD;
    alpha = 0.42 + amt * 0.58;
    rad = 1.85 + bolus * 1.4;
  } else if (p.tract === "norepinephrine") {
    amt = clamp(0.16 + drive.norepinephrine * 0.95);
    hot = NE;
    alpha = 0.36 + amt * 0.64;
    rad = 1.7;
  } else if (p.tract === "memory") {
    amt = clamp(0.14 + Math.max(drive.memory, drive.auditory * 0.45));
    hot = MEM;
    alpha = 0.34 + amt * 0.62;
    rad = 1.65;
  } else if (p.tract === "motor") {
    amt = clamp(0.16 + Math.max(drive.beat, drive.bass * 0.5));
    hot = MOTOR;
    alpha = 0.36 + amt * 0.64;
    rad = 1.65 + drive.beat * 0.6;
  } else if (p.tract === "callosum") {
    amt = clamp(0.2 + drive.energy * 0.45);
    hot = PAPER;
    alpha = 0.4 + amt * 0.4;
    rad = 1.45;
  } else {
    const painted = regionPaint(p, drive);
    hot = painted.hot;
    amt = painted.amt;
    rad *= painted.rad;
    if (isCortex(p.region) && drive.norepinephrine > 0) {
      hot = mixRgb(hot, NE, drive.norepinephrine * (p.receptor === 2 ? 0.55 : 0.12));
    }
  }

  if (p.receptor === 1 && p.tract === "none") {
    const pulse = drive.dopamine * (0.5 + 0.5 * Math.sin(drive.time * 6.5 + p.phase * 11) ** 2);
    amt = Math.max(amt, pulse);
    hot = mixRgb(hot, GOLD, 0.35 + pulse * 0.65);
    rad *= 1 + pulse * 0.9;
    alpha = Math.max(alpha, 0.45 + pulse * 0.55);
  } else if (p.receptor === 2 && p.tract === "none") {
    const gate = hash01(p.id * 19 + Math.floor(drive.time * 8));
    const pulse = drive.norepinephrine * (gate > 0.4 ? 1 : 0.15);
    amt = Math.max(amt, pulse);
    hot = mixRgb(hot, NE, 0.4 + pulse * 0.6);
    rad *= 1 + pulse * 0.75;
  }

  if (p.region === "pfc" && drive.chordFlash > 0.02) {
    hot = mixRgb(hot, PAPER, drive.chordFlash * (0.35 + 0.4 * p.fold));
    amt = Math.max(amt, drive.chordFlash);
  }

  const k = clamp(amt, 0, 1);
  const r = (STONE[0] + (hot[0] - STONE[0]) * k) * tone;
  const g = (STONE[1] + (hot[1] - STONE[1]) * k) * tone;
  const b = (STONE[2] + (hot[2] - STONE[2]) * k) * tone;

  if (!drive.playing) {
    rad *= 1 + Math.sin(drive.time * 0.75 + p.phase * 6.2) * 0.035;
  }

  return {
    r: clamp(r, 0, 255),
    g: clamp(g, 0, 255),
    b: clamp(b, 0, 255),
    a: clamp(alpha, 0, 1),
    rad,
  };
}

function regionPaint(p: BrainPoint, drive: Drive): { hot: RGB; amt: number; rad: number } {
  const playing = drive.playing;
  switch (p.region) {
    case "pfc": {
      const tide = Math.sin(drive.time * (0.4 + drive.harmonic * 0.8) + p.phase * 6.2 + p.x * 2.4);
      const mode = clamp(drive.modeFast * 0.5 + 0.5 + tide * 0.07, 0, 1);
      return {
        hot: mixRgb(MINOR, MAJOR, mode),
        amt: playing
          ? clamp(0.42 + 0.58 * Math.max(drive.harmonic, drive.chordFlash, Math.abs(drive.modeFast)))
          : 0,
        rad: 1,
      };
    }
    case "amygdala":
    case "hippocampus": {
      const tide = Math.sin(drive.time * 0.3 + p.phase * 5 + p.y * 3);
      const mode = clamp(drive.modeSlow * 0.5 + 0.5 + tide * 0.12, 0, 1);
      let hot = mixRgb(LIMBIC_MINOR, LIMBIC_MAJOR, mode);
      hot = mixRgb(hot, ROSE, drive.tension * 0.7);
      const memoryBoost = p.region === "hippocampus" ? drive.memory : 0;
      return {
        hot: memoryBoost > 0.2 ? mixRgb(hot, MEM, memoryBoost * 0.6) : hot,
        amt: playing
          ? clamp(0.38 + 0.62 * Math.max(Math.abs(drive.modeSlow), drive.tension, memoryBoost))
          : 0.12,
        rad: 1 + memoryBoost * 0.25,
      };
    }
    case "temporal": {
      const place = clamp((p.y + 0.42) / 0.52, 0, 1);
      const band = Math.exp(-((place - drive.pitchNorm) ** 2) / 0.016);
      return {
        hot: AUD,
        amt: playing ? clamp(drive.auditory * (0.3 + band * drive.pitchConf * 1.15)) : 0,
        rad: 1 + (playing ? band * drive.pitchConf * 0.28 : 0),
      };
    }
    case "motor":
    case "cerebellum":
      return {
        hot: MOTOR,
        amt: playing ? clamp(0.18 + drive.beat * 0.95 + drive.bass * 0.28) : 0,
        rad: 1 + drive.beat * 0.42,
      };
    case "occipital":
      return {
        hot: OCC,
        amt: playing ? clamp(drive.highs * 1.15) : 0,
        rad: 1 + drive.highs * 0.2,
      };
    case "nacc":
    case "vta":
      return {
        hot: GOLD,
        amt: clamp(0.34 + drive.dopamine * 0.85),
        rad: 1.25 + drive.dopamine * 0.7,
      };
    case "lc":
      return {
        hot: NE,
        amt: clamp(0.36 + drive.norepinephrine * 0.8),
        rad: 1.2 + drive.norepinephrine * 0.65,
      };
    case "brainstem":
      return {
        hot: mixRgb(STONE, NE, 0.35),
        amt: playing ? clamp(drive.norepinephrine * 0.7 + drive.bass * 0.2) : 0.08,
        rad: 1,
      };
    default:
      return {
        hot: STONE,
        amt: playing ? clamp(drive.energy * 0.28) : 0,
        rad: 1,
      };
  }
}

function isCortex(region: Region): boolean {
  return (
    region === "pfc" ||
    region === "motor" ||
    region === "parietal" ||
    region === "occipital" ||
    region === "temporal" ||
    region === "cerebellum"
  );
}

function stampSynapse(
  syn: Synapse,
  n: number,
  drive: Drive,
  view: View,
  fit: number,
  viewCx: number,
  viewCy: number,
): number {
  const count = 8 + Math.round(syn.strength * 16);
  for (let i = 0; i < count; i += 1) {
    const t = count === 1 ? 1 : i / (count - 1);
    if (t > syn.reveal + 0.02) break;
    const o = 1 - t;
    const x = o * o * syn.ax + 2 * o * t * syn.cx + t * t * syn.bx;
    const y = o * o * syn.ay + 2 * o * t * syn.cy + t * t * syn.by;
    const z = o * o * syn.az + 2 * o * t * syn.cz + t * t * syn.bz;
    const proj = project(x, y, z, view.yaw, view.pitch);
    const stamp = pool[n];
    if (!stamp) return n;
    const grow = t > syn.reveal ? 0.2 : 1;
    const head = t > syn.reveal - 0.12 ? 1 : 0.75;
    stamp.x = viewCx + proj.x * fit;
    stamp.y = viewCy - proj.y * fit;
    stamp.depth = proj.z + 0.22;
    const mix = 0.45 + syn.strength * 0.55;
    stamp.r = lerp(210, 232, mix) * head;
    stamp.g = lerp(200, 214, mix) * head;
    stamp.b = lerp(190, 236, mix) * head;
    stamp.a = (0.45 + syn.strength * 0.5) * grow;
    stamp.rad = (1.7 + syn.strength * 1.5) * (fit / 300) * proj.p * (i === count - 1 ? 1.35 : 1);
    n += 1;
  }
  return n;
}

function drawLabels(
  ctx: CanvasRenderingContext2D,
  view: View,
  fit: number,
  viewCx: number,
  viewCy: number,
  scale: number,
): void {
  ctx.save();
  ctx.font = `500 ${Math.max(11, Math.round(12 * scale))}px Outfit, sans-serif`;
  ctx.textBaseline = "middle";
  ctx.fillStyle = "rgba(243, 236, 223, 0.72)";
  for (const label of LABEL_ANCHORS) {
    const proj = project(label.at[0], label.at[1], label.at[2], view.yaw, view.pitch);
    const sx = viewCx + proj.x * fit;
    const sy = viewCy - proj.y * fit;
    const dx = sx - viewCx;
    const dy = sy - viewCy;
    const m = Math.hypot(dx, dy) || 1;
    const lx = sx + (dx / m) * 34 * scale;
    const ly = sy + (dy / m) * 26 * scale;
    ctx.textAlign = dx > 8 ? "left" : dx < -8 ? "right" : "center";
    ctx.fillText(label.text, lx, ly);
  }
  ctx.restore();
}

function blot(
  data: Uint8ClampedArray,
  w: number,
  h: number,
  x: number,
  y: number,
  rad: number,
  cr: number,
  cg: number,
  cb: number,
  ca: number,
): void {
  const r = Math.max(0.8, Math.min(rad, 6.5));
  const r2 = r * r;
  const x0 = Math.round(x);
  const y0 = Math.round(y);
  const ri = Math.ceil(r);
  for (let dy = -ri; dy <= ri; dy += 1) {
    const py = y0 + dy;
    if (py < 0 || py >= h) continue;
    const row = py * w;
    for (let dx = -ri; dx <= ri; dx += 1) {
      const px = x0 + dx;
      if (px < 0 || px >= w) continue;
      const ddx = px + 0.5 - x;
      const ddy = py + 0.5 - y;
      const d2 = ddx * ddx + ddy * ddy;
      if (d2 > r2) continue;
      const fall = 1 - d2 / r2;
      const cover = ca * fall * fall;
      const i = (row + px) * 4;
      const inv = 1 - cover;
      const core = 0.72 + 0.28 * fall;
      data[i] = data[i] * inv + cr * core * cover;
      data[i + 1] = data[i + 1] * inv + cg * core * cover;
      data[i + 2] = data[i + 2] * inv + cb * core * cover;
    }
  }
}

function mixRgb(a: RGB, b: RGB, t: number): RGB {
  const k = clamp(t, 0, 1);
  return [a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k, a[2] + (b[2] - a[2]) * k];
}

function normalize(x: number, y: number, z: number): [number, number, number] {
  const m = Math.hypot(x, y, z) || 1;
  return [x / m, y / m, z / m];
}
