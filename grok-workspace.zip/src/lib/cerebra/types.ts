export type SourceKind = "idle" | "mic" | "study" | "file";

export type SynapseRegion =
  | "pfc"
  | "temporal"
  | "motor"
  | "limbic"
  | "occipital"
  | "cerebellum";

export interface Synapse {
  id: number;
  born: number;
  strength: number;
  reveal: number;
  ax: number;
  ay: number;
  az: number;
  bx: number;
  by: number;
  bz: number;
  cx: number;
  cy: number;
  cz: number;
  region: SynapseRegion;
}

export interface Drive {
  time: number;
  playing: boolean;
  dopamine: number;
  norepinephrine: number;
  modeFast: number;
  modeSlow: number;
  chordFlash: number;
  tension: number;
  auditory: number;
  pitchNorm: number;
  pitchConf: number;
  beat: number;
  harmonic: number;
  memory: number;
  energy: number;
  highs: number;
  bass: number;
  synapses: Synapse[];
}

export interface Levels {
  pfc: number;
  limbic: number;
  dopamine: number;
  norepinephrine: number;
  auditory: number;
  motor: number;
  memory: number;
}

export interface Readout {
  bpm: string;
  key: string;
  chord: string;
  links: number;
  source: SourceKind;
  fileName: string;
  message: string;
  levels: Levels;
}

export const IDLE_READOUT: Readout = {
  bpm: "—",
  key: "—",
  chord: "—",
  links: 0,
  source: "idle",
  fileName: "",
  message: "",
  levels: {
    pfc: 0.08,
    limbic: 0.08,
    dopamine: 0.06,
    norepinephrine: 0.06,
    auditory: 0.08,
    motor: 0.08,
    memory: 0.06,
  },
};
