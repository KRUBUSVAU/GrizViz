import { createFileRoute } from "@tanstack/react-router";
import { CerebraStage } from "@/components/cerebra-stage";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <CerebraStage />;
}
