import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Mic, i as Play, r as Square, t as Upload } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D9hT8NiP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function clamp(v, a = 0, b = 1) {
	return Math.max(a, Math.min(b, v));
}
function lerp(a, b, t) {
	return a + (b - a) * t;
}
function toward(cur, target, dt, tau) {
	if (tau <= 1e-4) return target;
	return cur + (target - cur) * (1 - Math.exp(-dt / tau));
}
function mulberry32(seed) {
	let s = seed >>> 0;
	return () => {
		s = s + 1831565813 >>> 0;
		let t = Math.imul(s ^ s >>> 15, 1 | s);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function hash01(n) {
	const x = Math.sin(n * 127.1 + 311.7) * 43758.5453;
	return x - Math.floor(x);
}
var ANCHORS = {
	hippocampus: [
		.08,
		-.12,
		.14
	],
	pfc: [
		.58,
		.34,
		.2
	],
	temporal: [
		.3,
		-.18,
		.26
	],
	motor: [
		.14,
		.52,
		.22
	],
	limbic: [
		.28,
		-.04,
		.12
	],
	occipital: [
		-.58,
		.12,
		.16
	],
	cerebellum: [
		-.42,
		-.22,
		.16
	]
};
var LEFT = [
	{
		cx: .02,
		cy: .2,
		cz: .2,
		rx: .86,
		ry: .5,
		rz: .22
	},
	{
		cx: .5,
		cy: .16,
		cz: .18,
		rx: .4,
		ry: .4,
		rz: .2
	},
	{
		cx: -.05,
		cy: .5,
		cz: .16,
		rx: .46,
		ry: .24,
		rz: .19
	},
	{
		cx: -.6,
		cy: .12,
		cz: .14,
		rx: .3,
		ry: .28,
		rz: .17
	},
	{
		cx: .24,
		cy: -.18,
		cz: .22,
		rx: .5,
		ry: .24,
		rz: .17
	}
];
var CEREBELLUM_L = [{
	cx: -.46,
	cy: -.2,
	cz: .14,
	rx: .3,
	ry: .21,
	rz: .15
}, {
	cx: -.3,
	cy: -.1,
	cz: .1,
	rx: .16,
	ry: .12,
	rz: .11
}];
var VERMIS = [{
	cx: -.44,
	cy: -.16,
	cz: 0,
	rx: .18,
	ry: .13,
	rz: .07
}];
var STEM = [{
	cx: .02,
	cy: -.48,
	cz: 0,
	rx: .1,
	ry: .32,
	rz: .09
}, {
	cx: .06,
	cy: -.36,
	cz: 0,
	rx: .14,
	ry: .11,
	rz: .11
}];
function mirror(list) {
	return list.map((s) => ({
		...s,
		cz: -s.cz
	}));
}
function ellipsoidK(x, y, z, s) {
	const dx = (x - s.cx) / s.rx;
	const dy = (y - s.cy) / s.ry;
	const dz = (z - s.cz) / s.rz;
	return Math.hypot(dx, dy, dz);
}
function nearest(x, y, z, shapes) {
	let k = Infinity;
	let best = shapes[0];
	for (const s of shapes) {
		const v = ellipsoidK(x, y, z, s);
		if (v < k) {
			k = v;
			best = s;
		}
	}
	return {
		k,
		s: best
	};
}
function outwardNormal(x, y, z, s) {
	const dx = (x - s.cx) / (s.rx * s.rx);
	const dy = (y - s.cy) / (s.ry * s.ry);
	const dz = (z - s.cz) / (s.rz * s.rz);
	const m = Math.hypot(dx, dy, dz) || 1;
	return [
		dx / m,
		dy / m,
		dz / m
	];
}
function gyrus(x, y, z) {
	const a = Math.sin(x * 11.2 + y * 2.1 + z * 4.2);
	const b = Math.sin(x * 3.6 - y * 12.4 + z * 7.5);
	const c = Math.sin((x + z) * 7.2 + y * 5.4);
	return a * .5 + b * .34 + c * .22;
}
function inCentralSulcus(x, y, z) {
	if (y < .02 || y > .74 || Math.abs(z) < .12) return false;
	const line = .1 + (.52 - y) * .32;
	return Math.abs(x - line) < .02;
}
function inSylvian(x, y, z) {
	if (x < -.22 || x > .78 || Math.abs(z) < .1) return false;
	const line = -.01 + (.62 - x) * .2;
	return Math.abs(y - line) < .022;
}
function cerebrumRegion(x, y) {
	if (y < .05 && x > -.28 && x < .78) return "temporal";
	if (x > .3 && y > -.02) return "pfc";
	if (x > -.02 && x <= .34 && y > .12) return "motor";
	if (x < -.4) return "occipital";
	return "parietal";
}
function cortexReceptor(region, shell, rng) {
	if (shell < .72) return 0;
	if (region === "pfc" && rng() < .18) return 1;
	if (rng() < .08) return 2;
	return 0;
}
function bbox(shapes) {
	let x0 = Infinity;
	let y0 = Infinity;
	let z0 = Infinity;
	let x1 = -Infinity;
	let y1 = -Infinity;
	let z1 = -Infinity;
	for (const s of shapes) {
		x0 = Math.min(x0, s.cx - s.rx);
		y0 = Math.min(y0, s.cy - s.ry);
		z0 = Math.min(z0, s.cz - s.rz);
		x1 = Math.max(x1, s.cx + s.rx);
		y1 = Math.max(y1, s.cy + s.ry);
		z1 = Math.max(z1, s.cz + s.rz);
	}
	return [
		x0,
		y0,
		z0,
		x1,
		y1,
		z1
	];
}
function sampleVolume(shapes, target, seed, accept, decorate) {
	const rng = mulberry32(seed);
	const [x0, y0, z0, x1, y1, z1] = bbox(shapes);
	const out = [];
	let guard = 0;
	const limit = target * 70;
	while (out.length < target && guard < limit) {
		guard += 1;
		const x = x0 + rng() * (x1 - x0);
		const y = y0 + rng() * (y1 - y0);
		const z = z0 + rng() * (z1 - z0);
		const hit = nearest(x, y, z, shapes);
		if (!accept(x, y, z, hit.k)) continue;
		const draft = decorate(x, y, z, hit.k, hit.s, rng);
		if (draft) out.push(draft);
	}
	return out;
}
function quad(a, c, b, n) {
	const pts = [];
	for (let i = 0; i < n; i += 1) {
		const t = n === 1 ? .5 : i / (n - 1);
		const o = 1 - t;
		pts.push([
			o * o * a[0] + 2 * o * t * c[0] + t * t * b[0],
			o * o * a[1] + 2 * o * t * c[1] + t * t * b[1],
			o * o * a[2] + 2 * o * t * c[2] + t * t * b[2],
			t
		]);
	}
	return pts;
}
function tractPoints(samples, tract, region, hemi, jitter, rng) {
	return samples.map(([x, y, z, u]) => ({
		x: x + (rng() - .5) * jitter,
		y: y + (rng() - .5) * jitter,
		z: z + (rng() - .5) * jitter,
		nx: 0,
		ny: 1,
		nz: hemi === 0 ? .2 : hemi,
		region,
		tract,
		u,
		phase: rng(),
		fold: .85,
		shell: 1,
		receptor: tract === "dopamine" ? 1 : tract === "norepinephrine" ? 2 : 0,
		hemi
	}));
}
function buildDrafts() {
	const cerebrum = [...LEFT, ...mirror(LEFT)];
	const cerebellum = [
		...CEREBELLUM_L,
		...mirror(CEREBELLUM_L),
		...VERMIS
	];
	const drafts = [];
	const surface = sampleVolume(cerebrum, 8200, 11, (_x, _y, _z, k) => k <= 1 && k >= .86, (x, y, z, k, s, rng) => {
		if (Math.abs(z) < .028 && y > -.06) return null;
		if (inCentralSulcus(x, y, z) && rng() < .82) return null;
		if (inSylvian(x, y, z) && rng() < .88) return null;
		const g = gyrus(x, y, z);
		if (g > .62 && k > .92 && rng() < .75) return null;
		const n = outwardNormal(x, y, z, s);
		const push = -g * .028;
		const region = cerebrumRegion(x, y);
		const shell = 1 - (1 - k) / .14;
		return {
			x: x + n[0] * push,
			y: y + n[1] * push,
			z: z + n[2] * push,
			nx: n[0],
			ny: n[1],
			nz: n[2],
			region,
			tract: "none",
			u: 0,
			phase: rng(),
			fold: Math.max(0, Math.min(1, .5 - g * .55)),
			shell: Math.max(0, Math.min(1, shell)),
			receptor: cortexReceptor(region, shell, rng),
			hemi: z >= 0 ? 1 : -1
		};
	});
	const deep = sampleVolume(cerebrum, 1100, 29, (x, y, z, k) => k > .42 && k < .8 && !(Math.abs(z) < .03 && y > .05), (x, y, z, k, s, rng) => {
		const n = outwardNormal(x, y, z, s);
		return {
			x,
			y,
			z,
			nx: n[0],
			ny: n[1],
			nz: n[2],
			region: cerebrumRegion(x, y),
			tract: "none",
			u: 0,
			phase: rng(),
			fold: .45,
			shell: Math.max(0, Math.min(1, (k - .42) / .5)),
			receptor: 0,
			hemi: z >= 0 ? 1 : -1
		};
	});
	const cereb = sampleVolume(cerebellum, 1600, 47, (_x, _y, _z, k) => k <= 1 && k >= .55, (x, y, z, k, s, rng) => {
		const folia = Math.sin(y * 62 + x * 10 + z * 6);
		if (k > .82 && folia < -.15 && rng() < .72) return null;
		const n = outwardNormal(x, y, z, s);
		const shell = k > .8 ? 1 : .45;
		return {
			x,
			y,
			z,
			nx: n[0],
			ny: n[1],
			nz: n[2],
			region: "cerebellum",
			tract: "none",
			u: 0,
			phase: rng(),
			fold: Math.max(0, Math.min(1, .5 + folia * .5)),
			shell,
			receptor: shell > .8 && rng() < .06 ? 2 : 0,
			hemi: Math.abs(z) < .04 ? 0 : z > 0 ? 1 : -1
		};
	});
	const stem = sampleVolume(STEM, 420, 71, (_x, _y, _z, k) => k <= 1 && k >= .35, (x, y, z, k, s, rng) => {
		const n = outwardNormal(x, y, z, s);
		return {
			x,
			y,
			z,
			nx: n[0],
			ny: n[1],
			nz: n[2],
			region: "brainstem",
			tract: "none",
			u: 0,
			phase: rng(),
			fold: .6,
			shell: k > .75 ? .9 : .4,
			receptor: 0,
			hemi: 0
		};
	});
	drafts.push(...surface, ...deep, ...cereb, ...stem);
	const rng = mulberry32(101);
	for (const nuc of [
		{
			region: "amygdala",
			c: [
				.34,
				-.06,
				.1
			],
			s: [
				.055,
				.045,
				.04
			],
			n: 70,
			receptor: 0,
			both: true
		},
		{
			region: "hippocampus",
			c: [
				.06,
				-.13,
				.1
			],
			s: [
				.12,
				.045,
				.04
			],
			n: 90,
			receptor: 0,
			both: true
		},
		{
			region: "nacc",
			c: [
				.38,
				0,
				.07
			],
			s: [
				.05,
				.04,
				.035
			],
			n: 64,
			receptor: 1,
			both: true
		},
		{
			region: "vta",
			c: [
				.04,
				-.28,
				0
			],
			s: [
				.045,
				.04,
				.04
			],
			n: 56,
			receptor: 1,
			both: false
		},
		{
			region: "lc",
			c: [
				-.02,
				-.42,
				0
			],
			s: [
				.03,
				.028,
				.028
			],
			n: 40,
			receptor: 2,
			both: false
		}
	]) {
		const sides = nuc.both ? [1, -1] : [0];
		for (const side of sides) for (let i = 0; i < nuc.n; i += 1) {
			const x = nuc.c[0] + (rng() - .5) * 2 * nuc.s[0];
			const y = nuc.c[1] + (rng() - .5) * 2 * nuc.s[1];
			const z = (nuc.both ? nuc.c[2] * side : nuc.c[2]) + (rng() - .5) * 2 * nuc.s[2];
			drafts.push({
				x,
				y,
				z,
				nx: .1,
				ny: .4,
				nz: side === 0 ? .2 : side * .7,
				region: nuc.region,
				tract: "none",
				u: 0,
				phase: rng(),
				fold: .9,
				shell: 1,
				receptor: nuc.receptor,
				hemi: side === 0 ? 0 : side > 0 ? 1 : -1
			});
		}
	}
	const tractRng = mulberry32(211);
	const addTract = (chains, tract, region, hemi, count) => {
		const per = Math.max(8, Math.floor(count / chains.length));
		for (const [a, c, b] of chains) drafts.push(...tractPoints(quad(a, c, b, per), tract, region, hemi, .012, tractRng));
	};
	for (const side of [1, -1]) {
		const z = (v) => v * side;
		addTract([[
			[
				.04,
				-.28,
				.02 * side
			],
			[
				.22,
				-.08,
				z(.1)
			],
			[
				.38,
				0,
				z(.08)
			]
		], [
			[
				.38,
				0,
				z(.08)
			],
			[
				.5,
				.18,
				z(.18)
			],
			[
				.6,
				.36,
				z(.18)
			]
		]], "dopamine", "nacc", side, 70);
		addTract([
			[
				[
					-.02,
					-.42,
					0
				],
				[
					.22,
					.05,
					z(.16)
				],
				[
					.55,
					.4,
					z(.18)
				]
			],
			[
				[
					-.02,
					-.42,
					0
				],
				[
					.12,
					-.16,
					z(.2)
				],
				[
					.32,
					-.16,
					z(.26)
				]
			],
			[
				[
					-.02,
					-.42,
					0
				],
				[
					-.28,
					-.05,
					z(.14)
				],
				[
					-.55,
					.16,
					z(.16)
				]
			]
		], "norepinephrine", "lc", side, 90);
		addTract([[
			[
				.32,
				-.16,
				z(.24)
			],
			[
				.16,
				-.08,
				z(.16)
			],
			[
				.08,
				-.12,
				z(.12)
			]
		], [
			[
				.08,
				-.12,
				z(.12)
			],
			[
				.32,
				.12,
				z(.2)
			],
			[
				.56,
				.32,
				z(.18)
			]
		]], "memory", "hippocampus", side, 64);
		addTract([[
			[
				.12,
				.5,
				z(.2)
			],
			[
				.08,
				.12,
				z(.1)
			],
			[
				.02,
				-.4,
				z(.04)
			]
		]], "motor", "motor", side, 36);
	}
	const callosum = quad([
		-.42,
		.16,
		0
	], [
		.02,
		.4,
		0
	], [
		.4,
		.14,
		0
	], 80);
	drafts.push(...tractPoints(callosum, "callosum", "parietal", 0, .01, tractRng));
	const callosumLow = quad([
		-.38,
		.08,
		0
	], [
		.02,
		.28,
		0
	], [
		.36,
		.06,
		0
	], 50);
	drafts.push(...tractPoints(callosumLow, "callosum", "parietal", 0, .012, tractRng));
	return drafts;
}
var cached = null;
function getBrain() {
	if (cached) return cached;
	cached = buildDrafts().map((d, id) => ({
		...d,
		id
	}));
	return cached;
}
var LABEL_ANCHORS = [
	{
		text: "Prefrontal",
		at: [
			.78,
			.28,
			.12
		]
	},
	{
		text: "Limbic",
		at: [
			.36,
			-.02,
			0
		]
	},
	{
		text: "Auditory",
		at: [
			.55,
			-.32,
			.18
		]
	},
	{
		text: "Dopamine",
		at: [
			.5,
			.08,
			0
		]
	},
	{
		text: "Motor",
		at: [
			.02,
			.72,
			.12
		]
	},
	{
		text: "Hippocampus",
		at: [
			.02,
			-.28,
			0
		]
	}
];
var IDLE_READOUT = {
	bpm: "—",
	key: "—",
	chord: "—",
	links: 0,
	source: "idle",
	fileName: "",
	message: "",
	levels: {
		pfc: .08,
		limbic: .08,
		dopamine: .06,
		norepinephrine: .06,
		auditory: .08,
		motor: .08,
		memory: .06
	}
};
var PC = [
	"C",
	"C♯",
	"D",
	"E♭",
	"E",
	"F",
	"F♯",
	"G",
	"A♭",
	"A",
	"B♭",
	"B"
];
var KK_MAJOR = [
	6.35,
	2.23,
	3.48,
	2.33,
	4.38,
	4.09,
	2.52,
	5.19,
	2.39,
	3.66,
	2.29,
	2.88
];
var KK_MINOR = [
	6.33,
	2.68,
	3.52,
	5.38,
	2.6,
	3.53,
	2.54,
	4.75,
	3.98,
	2.69,
	3.34,
	3.17
];
function buildScore() {
	const events = [];
	const C = [
		48,
		52,
		55,
		64
	];
	const Am = [
		45,
		52,
		57,
		64
	];
	const F = [
		41,
		53,
		57,
		65
	];
	const G = [
		43,
		50,
		55,
		59
	];
	const Cm = [
		48,
		51,
		55,
		63
	];
	const Ab = [
		44,
		51,
		56,
		63
	];
	const Fm = [
		41,
		53,
		56,
		65
	];
	const Bb = [
		46,
		53,
		58,
		65
	];
	const section = (opts) => {
		const beat = 60 / opts.bpm;
		const bar = beat * 4;
		let t = opts.start;
		for (let i = 0; i < opts.bars; i += 1) {
			const chord = opts.chords[i % opts.chords.length];
			events.push({
				t,
				kind: "chord",
				midis: chord,
				dur: bar * .94,
				gain: opts.chordGain
			});
			events.push({
				t,
				kind: "kick",
				gain: opts.kick
			});
			for (let b = 0; b < 4; b += 1) events.push({
				t: t + b * beat,
				kind: "hat",
				gain: b === 0 ? opts.hat : opts.hat * .58
			});
			for (let n = 0; n < 8; n += 1) events.push({
				t: t + n * beat * .5,
				kind: "note",
				midi: opts.motif[n % opts.motif.length],
				dur: beat * .46,
				gain: opts.noteGain
			});
			t += bar;
		}
		return t;
	};
	let t = 0;
	t = section({
		start: t,
		bars: 4,
		bpm: 96,
		chords: [
			C,
			Am,
			F,
			G
		],
		motif: [
			76,
			79,
			84,
			86
		],
		hat: .08,
		chordGain: .015,
		noteGain: .1,
		kick: .26
	});
	const riseStart = t;
	t = section({
		start: t,
		bars: 2,
		bpm: 96,
		chords: [C, C],
		motif: [
			76,
			79,
			83,
			88
		],
		hat: .07,
		chordGain: .018,
		noteGain: .11,
		kick: .2
	});
	events.push({
		t: riseStart + (t - riseStart) - 1.55,
		kind: "riser",
		dur: 1.45
	});
	t = section({
		start: t,
		bars: 4,
		bpm: 96,
		chords: [
			Cm,
			Ab,
			Fm,
			Bb
		],
		motif: [
			75,
			79,
			82,
			87
		],
		hat: .08,
		chordGain: .015,
		noteGain: .1,
		kick: .24
	});
	t = section({
		start: t,
		bars: 4,
		bpm: 132,
		chords: [
			C,
			Am,
			F,
			G
		],
		motif: [
			76,
			79,
			84,
			86
		],
		hat: .1,
		chordGain: .014,
		noteGain: .09,
		kick: .32
	});
	t = section({
		start: t,
		bars: 2,
		bpm: 96,
		chords: [C, C],
		motif: [
			76,
			79,
			84,
			86
		],
		hat: .055,
		chordGain: .02,
		noteGain: .08,
		kick: .18
	});
	events.sort((a, b) => a.t - b.t);
	return {
		events,
		duration: t
	};
}
var StudyPlayer = class {
	ctx;
	output;
	events;
	duration;
	origin;
	cursor = 0;
	timer = 0;
	stopped = false;
	hat;
	live = /* @__PURE__ */ new Set();
	constructor(ctx, dest) {
		this.ctx = ctx;
		this.output = ctx.createGain();
		this.output.gain.value = .95;
		this.output.connect(dest);
		const score = buildScore();
		this.events = score.events;
		this.duration = score.duration;
		this.origin = ctx.currentTime + .06;
		const len = Math.floor(ctx.sampleRate * .028);
		this.hat = ctx.createBuffer(1, len, ctx.sampleRate);
		const data = this.hat.getChannelData(0);
		for (let i = 0; i < len; i += 1) data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (ctx.sampleRate * .0035));
		this.pump();
		this.timer = window.setInterval(() => this.pump(), 80);
	}
	track(stoppable, ...extra) {
		this.live.add(stoppable);
		for (const node of extra) this.live.add(node);
		stoppable.onended = () => {
			try {
				stoppable.disconnect();
			} catch {}
			for (const node of extra) {
				try {
					node.disconnect();
				} catch {}
				this.live.delete(node);
			}
			this.live.delete(stoppable);
		};
	}
	tone(when, freq, dur, type, peak, glide) {
		const osc = this.ctx.createOscillator();
		const gain = this.ctx.createGain();
		const filter = this.ctx.createBiquadFilter();
		osc.type = type;
		osc.frequency.setValueAtTime(Math.max(40, freq), when);
		if (glide) osc.frequency.exponentialRampToValueAtTime(Math.max(40, glide), when + dur);
		filter.type = "lowpass";
		filter.frequency.setValueAtTime(type === "sine" ? 1400 : 2200, when);
		filter.Q.value = .4;
		gain.gain.setValueAtTime(1e-4, when);
		gain.gain.exponentialRampToValueAtTime(Math.max(2e-4, peak), when + .02);
		gain.gain.exponentialRampToValueAtTime(1e-4, when + Math.max(.08, dur));
		osc.connect(gain);
		gain.connect(filter);
		filter.connect(this.output);
		osc.start(when);
		osc.stop(when + dur + .05);
		this.track(osc, gain, filter);
	}
	play(ev, when) {
		if (when < this.ctx.currentTime - .05) return;
		if (ev.kind === "chord") {
			for (const m of ev.midis) this.tone(when, midiHz(m), ev.dur, "sine", ev.gain);
			return;
		}
		if (ev.kind === "note") {
			this.tone(when, midiHz(ev.midi), ev.dur, "triangle", ev.gain);
			return;
		}
		if (ev.kind === "kick") {
			this.tone(when, 150, .16, "sine", ev.gain, 52);
			return;
		}
		if (ev.kind === "hat") {
			const src = this.ctx.createBufferSource();
			src.buffer = this.hat;
			const filter = this.ctx.createBiquadFilter();
			filter.type = "highpass";
			filter.frequency.value = 1600;
			const gain = this.ctx.createGain();
			gain.gain.value = ev.gain;
			src.connect(filter);
			filter.connect(gain);
			gain.connect(this.output);
			src.start(when);
			this.track(src, gain, filter);
			return;
		}
		const osc = this.ctx.createOscillator();
		const gain = this.ctx.createGain();
		const filter = this.ctx.createBiquadFilter();
		osc.type = "triangle";
		osc.frequency.setValueAtTime(180, when);
		osc.frequency.exponentialRampToValueAtTime(1200, when + ev.dur);
		filter.type = "lowpass";
		filter.frequency.setValueAtTime(500, when);
		filter.frequency.exponentialRampToValueAtTime(2800, when + ev.dur);
		gain.gain.setValueAtTime(1e-4, when);
		gain.gain.exponentialRampToValueAtTime(.07, when + ev.dur * .92);
		gain.gain.exponentialRampToValueAtTime(1e-4, when + ev.dur);
		osc.connect(filter);
		filter.connect(gain);
		gain.connect(this.output);
		osc.start(when);
		osc.stop(when + ev.dur + .02);
		this.track(osc, gain, filter);
	}
	pump() {
		if (this.stopped) return;
		const horizon = this.ctx.currentTime + .4;
		let guard = 0;
		while (guard < 500) {
			guard += 1;
			if (this.cursor >= this.events.length) {
				this.origin += this.duration;
				if (this.origin < this.ctx.currentTime - .15) this.origin = this.ctx.currentTime + .05;
				this.cursor = 0;
			}
			const ev = this.events[this.cursor];
			const when = this.origin + ev.t;
			if (when > horizon) break;
			this.play(ev, when);
			this.cursor += 1;
		}
	}
	stop() {
		this.stopped = true;
		window.clearInterval(this.timer);
		const t = this.ctx.currentTime;
		try {
			this.output.gain.cancelScheduledValues(t);
			this.output.gain.setTargetAtTime(1e-4, t, .02);
		} catch {}
		for (const node of this.live) {
			try {
				if (node instanceof OscillatorNode || node instanceof AudioBufferSourceNode) node.stop(t);
			} catch {}
			try {
				node.disconnect();
			} catch {}
		}
		this.live.clear();
		try {
			this.output.disconnect();
		} catch {}
	}
};
function midiHz(m) {
	return 440 * 2 ** ((m - 69) / 12);
}
function pearson(a, b) {
	let ma = 0;
	let mb = 0;
	for (let i = 0; i < 12; i += 1) {
		ma += a[i];
		mb += b[i];
	}
	ma /= 12;
	mb /= 12;
	let num = 0;
	let da = 0;
	let db = 0;
	for (let i = 0; i < 12; i += 1) {
		const xa = a[i] - ma;
		const xb = b[i] - mb;
		num += xa * xb;
		da += xa * xa;
		db += xb * xb;
	}
	return num / Math.sqrt(da * db + 1e-8);
}
function rotateProfile(profile, root) {
	const out = new Array(12);
	for (let i = 0; i < 12; i += 1) out[(i + root) % 12] = profile[i];
	return out;
}
function cosine12(a, b) {
	let dot = 0;
	let na = 0;
	let nb = 0;
	for (let i = 0; i < 12; i += 1) {
		dot += a[i] * b[i];
		na += a[i] * a[i];
		nb += b[i] * b[i];
	}
	return dot / Math.sqrt(na * nb + 1e-8);
}
var REGIONS = [
	"pfc",
	"temporal",
	"motor",
	"limbic",
	"occipital",
	"cerebellum"
];
function friendlyError(error) {
	if (error instanceof DOMException) {
		if (error.name === "NotAllowedError" || error.name === "PermissionDeniedError") return "Microphone blocked. Allow it in the browser bar, or play the study.";
		if (error.name === "NotFoundError") return "No microphone found. Play the study, or upload a recording.";
	}
	return "That audio didn't open. Try a wav or mp3, or play the study.";
}
var AudioSession = class {
	drive = {
		time: 0,
		playing: false,
		dopamine: 0,
		norepinephrine: 0,
		modeFast: 0,
		modeSlow: 0,
		chordFlash: 0,
		tension: 0,
		auditory: 0,
		pitchNorm: .5,
		pitchConf: 0,
		beat: 0,
		harmonic: 0,
		memory: 0,
		energy: 0,
		highs: 0,
		bass: 0,
		synapses: []
	};
	fileUrl = null;
	ctx = null;
	analyser = null;
	out = null;
	speakers = false;
	mediaSrc = null;
	audioEl = null;
	micStream = null;
	micGain = null;
	study = null;
	source = "idle";
	fileName = "";
	message = "";
	volume = .85;
	readout = IDLE_READOUT;
	listeners = /* @__PURE__ */ new Set();
	freq;
	prevFreq;
	time;
	fluxRing = /* @__PURE__ */ new Float32Array(800);
	fluxWrite = 0;
	fluxCount = 0;
	fluxAcc = 0;
	fluxHist = [];
	lastOnset = -10;
	prevRms = 0;
	rollRms = 0;
	daKick = 0;
	neKick = 0;
	riseEnv = 0;
	lastMidi = 0;
	haveMidi = false;
	melodyPc = -1;
	climb = 0;
	bpm = 0;
	bpmConf = 0;
	committedBpm = 0;
	bpmStreak = 0;
	bpmCandidate = 0;
	lastBpmAt = 0;
	keyName = "—";
	chordName = "—";
	chordStreak = 0;
	chordCandidate = "—";
	keyStreak = 0;
	keyCandidate = "—";
	chroma = /* @__PURE__ */ new Float32Array(12);
	prevChroma = /* @__PURE__ */ new Float32Array(12);
	haveChroma = false;
	snaps = [];
	snapAcc = 0;
	searchAcc = 0;
	lastRepeat = -10;
	synapseId = 1;
	salience = {
		pfc: 0,
		temporal: 0,
		motor: 0,
		limbic: 0,
		occipital: 0,
		cerebellum: 0
	};
	publishAcc = 0;
	simMatch = 0;
	constructor() {
		try {
			const stored = localStorage.getItem("cerebra-volume");
			if (stored != null) {
				const n = Number(stored);
				if (Number.isFinite(n)) this.volume = clamp(n, 0, 1);
			}
		} catch {}
	}
	subscribe = (fn) => {
		this.listeners.add(fn);
		return () => this.listeners.delete(fn);
	};
	getReadout = () => this.readout;
	getVolume() {
		return this.volume;
	}
	setVolume(v) {
		this.volume = clamp(v, 0, 1);
		if (this.out && this.ctx) this.out.gain.setTargetAtTime(this.volume, this.ctx.currentTime, .03);
		try {
			localStorage.setItem("cerebra-volume", String(this.volume));
		} catch {}
	}
	publish(force = false) {
		const levels = {
			pfc: q(clamp(.08 + .92 * Math.max(this.drive.chordFlash, this.drive.harmonic * .85, Math.abs(this.drive.modeFast) * .55))),
			limbic: q(clamp(.08 + .92 * Math.max(Math.abs(this.drive.modeSlow), this.drive.tension * .85))),
			dopamine: q(this.drive.dopamine),
			norepinephrine: q(this.drive.norepinephrine),
			auditory: q(this.drive.auditory),
			motor: q(Math.max(this.drive.beat, this.drive.bass * .75)),
			memory: q(this.drive.memory)
		};
		const next = {
			bpm: this.bpmConf > 1.55 && this.committedBpm > 0 ? String(Math.round(this.committedBpm)) : "—",
			key: this.keyName,
			chord: this.chordName,
			links: this.drive.synapses.length,
			source: this.source,
			fileName: this.fileName,
			message: this.message,
			levels
		};
		const prev = this.readout;
		if (!force && prev.bpm === next.bpm && prev.key === next.key && prev.chord === next.chord && prev.links === next.links && prev.source === next.source && prev.fileName === next.fileName && prev.message === next.message && prev.levels.pfc === next.levels.pfc && prev.levels.limbic === next.levels.limbic && prev.levels.dopamine === next.levels.dopamine && prev.levels.norepinephrine === next.levels.norepinephrine && prev.levels.auditory === next.levels.auditory && prev.levels.motor === next.levels.motor && prev.levels.memory === next.levels.memory) return;
		this.readout = next;
		for (const fn of this.listeners) fn();
	}
	setup() {
		const ctx = new AudioContext();
		const analyser = ctx.createAnalyser();
		analyser.fftSize = 2048;
		analyser.smoothingTimeConstant = .18;
		analyser.minDecibels = -90;
		analyser.maxDecibels = -12;
		const out = ctx.createGain();
		out.gain.value = this.volume;
		this.ctx = ctx;
		this.analyser = analyser;
		this.out = out;
		out.connect(ctx.destination);
		const bins = analyser.frequencyBinCount;
		this.freq = new Uint8Array(bins);
		this.prevFreq = new Uint8Array(bins);
		this.time = new Float32Array(analyser.fftSize);
		this.audioEl = new Audio();
		this.audioEl.loop = true;
		this.audioEl.preload = "auto";
	}
	nudge() {
		if (this.ctx && this.ctx.state === "suspended" && this.source !== "idle") this.ctx.resume();
	}
	async ensure() {
		if (!this.ctx) this.setup();
		const ctx = this.ctx;
		if (!ctx) throw new Error("Audio unavailable");
		if (ctx.state === "suspended") await ctx.resume();
		return ctx;
	}
	setSpeakers(on) {
		if (!this.analyser || !this.out) return;
		if (on === this.speakers) return;
		try {
			this.analyser.disconnect();
		} catch {}
		if (on) this.analyser.connect(this.out);
		this.speakers = on;
	}
	halt() {
		this.study?.stop();
		this.study = null;
		try {
			this.micGain?.disconnect();
		} catch {}
		this.micGain = null;
		if (this.micStream) {
			for (const track of this.micStream.getTracks()) track.stop();
			this.micStream = null;
		}
		try {
			this.mediaSrc?.disconnect();
		} catch {}
		if (this.audioEl) {
			this.audioEl.pause();
			this.audioEl.removeAttribute("src");
		}
		if (this.fileUrl) {
			URL.revokeObjectURL(this.fileUrl);
			this.fileUrl = null;
		}
		this.setSpeakers(false);
		this.source = "idle";
		this.fileName = "";
		this.drive.playing = false;
	}
	async stop() {
		this.halt();
		this.message = "";
		this.publish(true);
	}
	async startStudy() {
		const ctx = await this.ensure();
		this.halt();
		if (!this.analyser) return;
		this.setSpeakers(true);
		this.study = new StudyPlayer(ctx, this.analyser);
		this.source = "study";
		this.message = "";
		this.drive.playing = true;
		this.publish(true);
	}
	async startMic() {
		try {
			const ctx = await this.ensure();
			const stream = await navigator.mediaDevices.getUserMedia({
				audio: {
					echoCancellation: false,
					noiseSuppression: false,
					autoGainControl: false
				},
				video: false
			});
			this.halt();
			if (!this.analyser) return;
			const gain = ctx.createGain();
			gain.gain.value = 1.6;
			ctx.createMediaStreamSource(stream).connect(gain);
			gain.connect(this.analyser);
			this.micStream = stream;
			this.micGain = gain;
			this.setSpeakers(false);
			this.source = "mic";
			this.message = "";
			this.drive.playing = true;
			this.publish(true);
		} catch (error) {
			this.message = friendlyError(error);
			this.publish(true);
		}
	}
	async startFile(file) {
		try {
			const ctx = await this.ensure();
			if (!this.audioEl || !this.analyser) return;
			this.halt();
			const url = URL.createObjectURL(file);
			this.fileUrl = url;
			this.audioEl.src = url;
			if (!this.mediaSrc) this.mediaSrc = ctx.createMediaElementSource(this.audioEl);
			this.mediaSrc.connect(this.analyser);
			this.setSpeakers(true);
			await this.audioEl.play();
			this.source = "file";
			this.fileName = file.name;
			this.message = "";
			this.drive.playing = true;
			this.publish(true);
		} catch (error) {
			this.message = friendlyError(error);
			this.halt();
			this.publish(true);
		}
	}
	tick(dt) {
		const step = clamp(dt, 0, .05);
		this.drive.time += step;
		const playing = this.source !== "idle";
		this.drive.playing = playing;
		let rms = 0;
		let bass = 0;
		let mid = 0;
		let highs = 0;
		let flux = 0;
		let hz = 0;
		let conf = 0;
		if (playing && this.analyser && this.ctx) {
			this.analyser.getByteFrequencyData(this.freq);
			this.analyser.getFloatTimeDomainData(this.time);
			const sr = this.ctx.sampleRate;
			const fft = this.analyser.fftSize;
			rms = rmsOf(this.time);
			bass = band(this.freq, sr, fft, 40, 160);
			mid = band(this.freq, sr, fft, 300, 2800);
			highs = band(this.freq, sr, fft, 5e3, 14e3);
			flux = spectralFlux(this.freq, this.prevFreq);
			this.prevFreq.set(this.freq);
			const pitch = melodyPeak(this.freq, sr, fft);
			hz = pitch.hz;
			conf = pitch.conf;
			this.accumulateFlux(step, flux);
			this.maybeBpm();
			this.chromaFrom(this.freq, sr, fft);
		} else {
			rms = 0;
			this.haveChroma = false;
		}
		const energy = clamp(rms * 4.2);
		this.rollRms = toward(this.rollRms, rms, step, 1.4);
		const dRms = (rms - this.prevRms) / Math.max(step, .001);
		this.prevRms = rms;
		if (dRms > .35) this.riseEnv = Math.max(this.riseEnv, clamp(dRms / 6));
		this.riseEnv *= Math.exp(-step / .55);
		let semiDelta = 0;
		if (conf > .42 && hz > 90 && hz < 2200) {
			const midi = 69 + 12 * Math.log2(hz / 440);
			this.melodyPc = (Math.round(midi) % 12 + 12) % 12;
			if (this.haveMidi) {
				const jump = midi - this.lastMidi;
				if (Math.abs(jump) <= 11) {
					semiDelta = jump;
					if (jump > 0) this.climb += jump;
				}
			}
			this.lastMidi = midi;
			this.haveMidi = true;
			const norm = clamp((midi - 64) / 30, 0, 1);
			this.drive.pitchNorm = toward(this.drive.pitchNorm, norm, step, .08);
			this.drive.pitchConf = toward(this.drive.pitchConf, conf, step, .1);
		} else {
			this.melodyPc = -1;
			this.drive.pitchConf = toward(this.drive.pitchConf, 0, step, .2);
		}
		this.climb *= Math.exp(-step / .45);
		if (semiDelta > .7) this.riseEnv = Math.max(this.riseEnv, clamp(semiDelta / 6));
		if (this.climb > 1.5) this.riseEnv = Math.max(this.riseEnv, clamp(this.climb / 7));
		if (Math.abs(semiDelta) >= 5) this.neKick = Math.max(this.neKick, clamp(Math.abs(semiDelta) / 9));
		if (this.detectOnset(flux, playing)) {
			this.drive.beat = 1;
			this.lastOnset = this.drive.time;
			this.neKick = Math.max(this.neKick, clamp(flux * 2.2));
			if (bass > .42 && rms > this.rollRms * 1.12) this.daKick = Math.max(this.daKick, .85);
		} else this.drive.beat *= Math.exp(-step / .14);
		if (playing && this.committedBpm > 70 && this.lastOnset > 0) {
			const period = 60 / this.committedBpm;
			const phase = (this.drive.time - this.lastOnset) % period / period;
			const predicted = Math.exp(-(phase * phase) / .0035);
			this.drive.beat = Math.max(this.drive.beat, predicted * .8);
		}
		this.daKick *= Math.exp(-step / .48);
		this.neKick *= Math.exp(-step / .3);
		const daTarget = clamp(this.riseEnv * .85 + this.daKick + (energy > .25 ? this.riseEnv * .3 : 0));
		this.drive.dopamine = toward(this.drive.dopamine, playing ? daTarget : 0, step, playing ? .12 : .4);
		const neTarget = clamp(this.neKick + (playing ? energy * .08 : 0));
		this.drive.norepinephrine = toward(this.drive.norepinephrine, neTarget, step, .08);
		this.updateHarmony(step, playing, energy);
		this.drive.auditory = toward(this.drive.auditory, playing ? clamp(mid) : 0, step, .08);
		this.drive.highs = toward(this.drive.highs, playing ? clamp(highs) : 0, step, .1);
		this.drive.bass = toward(this.drive.bass, playing ? clamp(bass) : 0, step, .08);
		this.drive.energy = toward(this.drive.energy, playing ? energy : 0, step, .12);
		this.drive.tension = toward(this.drive.tension, playing ? dissonance(this.chroma) : 0, step, .35);
		this.salience.pfc = toward(this.salience.pfc, Math.max(this.drive.harmonic, this.drive.chordFlash), step, .35);
		this.salience.temporal = toward(this.salience.temporal, this.drive.auditory, step, .3);
		this.salience.motor = toward(this.salience.motor, Math.max(this.drive.beat, this.drive.bass), step, .25);
		this.salience.limbic = toward(this.salience.limbic, Math.max(this.drive.tension, Math.abs(this.drive.modeFast)), step, .4);
		this.salience.occipital = toward(this.salience.occipital, this.drive.highs, step, .3);
		this.salience.cerebellum = toward(this.salience.cerebellum, this.drive.beat, step, .25);
		this.memoryStep(step, playing);
		this.decaySynapses(step);
		if (!playing) {
			this.drive.chordFlash *= Math.exp(-step / .3);
			this.drive.modeFast = toward(this.drive.modeFast, 0, step, .6);
			this.drive.modeSlow = toward(this.drive.modeSlow, 0, step, 1.2);
			this.drive.harmonic = toward(this.drive.harmonic, 0, step, .4);
			this.drive.memory = toward(this.drive.memory, 0, step, .5);
		}
		this.publishAcc += step;
		if (this.publishAcc >= .12) {
			this.publishAcc = 0;
			this.publish();
		}
	}
	dispose() {
		this.halt();
		this.ctx?.close();
		this.ctx = null;
	}
	accumulateFlux(dt, flux) {
		this.fluxAcc += dt;
		let n = 0;
		while (this.fluxAcc >= .01 && n < 6) {
			this.fluxAcc -= .01;
			this.fluxRing[this.fluxWrite] = flux;
			this.fluxWrite = (this.fluxWrite + 1) % this.fluxRing.length;
			this.fluxCount = Math.min(this.fluxRing.length, this.fluxCount + 1);
			n += 1;
		}
	}
	maybeBpm() {
		if (this.drive.time - this.lastBpmAt < .28) return;
		if (this.fluxCount < 280) return;
		this.lastBpmAt = this.drive.time;
		const scores = /* @__PURE__ */ new Float32Array(181);
		let best = 0;
		let bestBpm = 0;
		let sum = 0;
		let tested = 0;
		const n = this.fluxCount;
		for (let bpm = 70; bpm <= 180; bpm += 1) {
			const lag = Math.round(60 / bpm / .01);
			if (lag < 8 || lag >= n - 8) continue;
			let acc = 0;
			let cnt = 0;
			for (let i = 0; i < n - lag; i += 2) {
				const i0 = (this.fluxWrite - n + i + this.fluxRing.length * 4) % this.fluxRing.length;
				const i1 = (i0 + lag) % this.fluxRing.length;
				acc += this.fluxRing[i0] * this.fluxRing[i1];
				cnt += 1;
			}
			const prior = Math.exp(-((bpm - 102) ** 2) / 2888);
			const score = acc / Math.max(1, cnt) * (.78 + .22 * prior);
			scores[bpm] = score;
			sum += score;
			tested += 1;
			if (score > best) {
				best = score;
				bestBpm = bpm;
			}
		}
		if (bestBpm > 145) {
			const half = Math.round(bestBpm / 2);
			if (half >= 70 && scores[half] > best * .8) bestBpm = half;
		}
		const mean = sum / Math.max(1, tested);
		const conf = best / (mean + 1e-6);
		this.bpm = bestBpm;
		this.bpmConf = conf;
		if (conf < 1.45) return;
		if (Math.abs(bestBpm - this.bpmCandidate) <= 3) this.bpmStreak += 1;
		else {
			this.bpmCandidate = bestBpm;
			this.bpmStreak = 1;
		}
		if (this.bpmStreak >= 3) {
			if (this.committedBpm > 0 && Math.abs(bestBpm - this.committedBpm) >= 8) {
				this.neKick = 1;
				if (bestBpm > this.committedBpm) this.daKick = Math.max(this.daKick, .9);
			}
			this.committedBpm = this.bpmCandidate;
		}
	}
	detectOnset(flux, playing) {
		if (!playing) return false;
		this.fluxHist.push(flux);
		if (this.fluxHist.length > 48) this.fluxHist.shift();
		let mean = 0;
		for (const v of this.fluxHist) mean += v;
		mean /= this.fluxHist.length;
		let variance = 0;
		for (const v of this.fluxHist) variance += (v - mean) ** 2;
		const std = Math.sqrt(variance / this.fluxHist.length);
		if (flux > mean + std * 1.35 + .012 && this.drive.time - this.lastOnset > .16) return true;
		return false;
	}
	chromaFrom(freq, sr, fft) {
		this.chroma.fill(0);
		const hzPer = sr / fft;
		const n = freq.length;
		for (let i = 2; i < n; i += 1) {
			const f = i * hzPer;
			if (f < 70 || f > 4200) continue;
			const mag = freq[i] / 255;
			if (mag < .08) continue;
			const midi = 69 + 12 * Math.log2(f / 440);
			const pc = (Math.round(midi) % 12 + 12) % 12;
			this.chroma[pc] += mag * mag;
		}
		let sum = 0;
		for (let i = 0; i < 12; i += 1) sum += this.chroma[i];
		if (sum > 0) for (let i = 0; i < 12; i += 1) this.chroma[i] /= sum;
	}
	updateHarmony(dt, playing, energy) {
		if (!playing || energy < .03) {
			this.drive.harmonic *= Math.exp(-dt / .4);
			return;
		}
		let delta = 0;
		if (this.haveChroma) delta = 1 - cosine12(this.chroma, this.prevChroma);
		this.prevChroma.set(this.chroma);
		this.haveChroma = true;
		const motion = clamp(delta * 2.4);
		this.drive.harmonic = toward(this.drive.harmonic, motion, dt, .2);
		let bestMaj = 0;
		let bestMin = 0;
		let majRoot = 0;
		let minRoot = 0;
		for (let root = 0; root < 12; root += 1) {
			const maj = this.chroma[root] + this.chroma[(root + 4) % 12] * .95 + this.chroma[(root + 7) % 12] * .85;
			const min = this.chroma[root] + this.chroma[(root + 3) % 12] * .95 + this.chroma[(root + 7) % 12] * .85;
			if (maj > bestMaj) {
				bestMaj = maj;
				majRoot = root;
			}
			if (min > bestMin) {
				bestMin = min;
				minRoot = root;
			}
		}
		const triadScore = Math.max(bestMaj, bestMin);
		const mode = triadScore < .18 ? 0 : (bestMaj - bestMin) / (bestMaj + bestMin + 1e-6);
		this.drive.modeFast = toward(this.drive.modeFast, mode, dt, .28);
		this.drive.modeSlow = toward(this.drive.modeSlow, mode, dt, 1.8);
		const chord = triadScore < .2 ? "—" : bestMaj >= bestMin ? `${PC[majRoot]} major` : `${PC[minRoot]} minor`;
		if (chord === this.chordCandidate) this.chordStreak += 1;
		else {
			this.chordCandidate = chord;
			this.chordStreak = 1;
		}
		if (this.chordStreak >= 4 && chord !== this.chordName) {
			if (this.chordName !== "—" && chord !== "—") this.drive.chordFlash = 1;
			this.chordName = chord;
		}
		this.drive.chordFlash *= Math.exp(-dt / .42);
		let bestKey = -1;
		let bestKeyScore = -Infinity;
		let bestMode = "major";
		for (let root = 0; root < 12; root += 1) {
			const maj = pearson(this.chroma, rotateProfile(KK_MAJOR, root));
			const min = pearson(this.chroma, rotateProfile(KK_MINOR, root));
			if (maj > bestKeyScore) {
				bestKeyScore = maj;
				bestKey = root;
				bestMode = "major";
			}
			if (min > bestKeyScore) {
				bestKeyScore = min;
				bestKey = root;
				bestMode = "minor";
			}
		}
		const key = bestKeyScore < .35 || bestKey < 0 ? "—" : `${PC[bestKey]} ${bestMode}`;
		if (key === this.keyCandidate) this.keyStreak += 1;
		else {
			this.keyCandidate = key;
			this.keyStreak = 1;
		}
		if (this.keyStreak >= 10) this.keyName = key;
	}
	memoryStep(dt, playing) {
		this.snapAcc += dt;
		if (playing && this.snapAcc >= .1) {
			this.snapAcc = 0;
			let energy = 0;
			for (let i = 0; i < 12; i += 1) energy += this.chroma[i];
			this.snaps.push({
				chroma: new Float32Array(this.chroma),
				energy,
				pc: this.melodyPc
			});
			if (this.snaps.length > 180) this.snaps.shift();
		}
		this.searchAcc += dt;
		if (!playing || this.searchAcc < .22) {
			this.simMatch *= Math.exp(-dt / 1.1);
			this.drive.memory = toward(this.drive.memory, this.simMatch, dt, .25);
			return;
		}
		this.searchAcc = 0;
		const win = 12;
		const snaps = this.snaps;
		if (snaps.length < 26) {
			this.drive.memory = toward(this.drive.memory, 0, dt, .3);
			return;
		}
		const end = snaps.length;
		let best = 0;
		const minLag = 8;
		const maxLag = Math.min(140, end - win - 1);
		for (let lag = minLag; lag <= maxLag; lag += 2) {
			let mel = 0;
			let harm = 0;
			let energy = 0;
			let voiced = 0;
			for (let i = 0; i < win; i += 1) {
				const cur = snaps[end - win + i];
				const past = snaps[end - win - lag + i];
				harm += cosine12(cur.chroma, past.chroma);
				energy += cur.energy;
				if (cur.pc >= 0 && cur.pc === past.pc) {
					mel += 1;
					voiced += 1;
				} else if (cur.pc >= 0 || past.pc >= 0) voiced += 1;
			}
			const sim = Math.max(harm / win, voiced > 4 ? mel / voiced : 0);
			if (energy / win < .12) continue;
			if (sim > best) best = sim;
		}
		if (best > .78 && this.drive.time - this.lastRepeat > .7) {
			this.lastRepeat = this.drive.time;
			this.simMatch = best;
			this.spawnSynapse();
		} else this.simMatch = Math.max(this.simMatch * Math.exp(-dt / .8), best > .72 ? best * .45 : 0);
		this.drive.memory = toward(this.drive.memory, clamp((best - .62) / .3), dt, .2);
	}
	spawnSynapse() {
		let region = "temporal";
		let best = .15;
		for (const key of REGIONS) if (this.salience[key] > best) {
			best = this.salience[key];
			region = key;
		}
		const recent = this.drive.synapses.find((s) => s.region === region && this.drive.time - s.born < 5);
		if (recent && recent.strength < .92) {
			recent.strength = Math.min(1, recent.strength + .22);
			recent.born = this.drive.time;
			return;
		}
		const from = ANCHORS.hippocampus;
		const to = ANCHORS[region];
		const seed = Math.random();
		const side = seed > .5 ? 1 : -1;
		const syn = {
			id: this.synapseId,
			born: this.drive.time,
			strength: .58,
			reveal: 0,
			ax: from[0],
			ay: from[1],
			az: from[2] * side,
			bx: to[0] + (seed - .5) * .05,
			by: to[1] + (seed - .5) * .05,
			bz: Math.abs(to[2]) * side,
			cx: (from[0] + to[0]) / 2 + (seed - .5) * .12,
			cy: Math.max(from[1], to[1]) + .14 + seed * .12,
			cz: (from[2] + Math.abs(to[2])) / 2 * side + .22 * side,
			region
		};
		this.synapseId += 1;
		this.drive.synapses.push(syn);
		if (this.drive.synapses.length > 18) {
			this.drive.synapses.sort((a, b) => a.strength - b.strength);
			this.drive.synapses.shift();
		}
	}
	decaySynapses(dt) {
		const list = this.drive.synapses;
		for (let i = list.length - 1; i >= 0; i -= 1) {
			const syn = list[i];
			syn.reveal = clamp((this.drive.time - syn.born) / .7, 0, 1);
			if (this.drive.time - syn.born > 6) syn.strength *= Math.exp(-dt / 16);
			if (syn.strength < .14) list.splice(i, 1);
		}
	}
};
function q(n) {
	return Math.round(clamp(n, 0, 1) * 32) / 32;
}
function rmsOf(buf) {
	let s = 0;
	let n = 0;
	for (let i = 0; i < buf.length; i += 8) {
		s += buf[i] * buf[i];
		n += 1;
	}
	return Math.sqrt(s / Math.max(1, n));
}
function band(freq, sr, fft, lo, hi) {
	const hzPer = sr / fft;
	const i0 = Math.max(0, Math.floor(lo / hzPer));
	const i1 = Math.min(freq.length - 1, Math.ceil(hi / hzPer));
	if (i1 <= i0) return 0;
	let peak = 0;
	let sum = 0;
	for (let i = i0; i <= i1; i += 1) {
		const v = freq[i];
		sum += v;
		if (v > peak) peak = v;
	}
	const mean = sum / (i1 - i0 + 1) / 255;
	return clamp(peak / 255 * .82 + mean * 1.5);
}
function spectralFlux(freq, prev) {
	let s = 0;
	for (let i = 1; i < freq.length; i += 2) {
		const d = freq[i] - prev[i];
		if (d > 0) s += d;
	}
	return s / (freq.length * 40);
}
function melodyPeak(freq, sr, fft) {
	const hzPer = sr / fft;
	const i0 = Math.max(1, Math.floor(300 / hzPer));
	const i1 = Math.min(freq.length - 2, Math.ceil(1800 / hzPer));
	let best = 0;
	let bestI = i0;
	for (let i = i0; i <= i1; i += 1) {
		const m = freq[i];
		if (m > best) {
			best = m;
			bestI = i;
		}
	}
	const conf = best / 255;
	if (conf < .18) return {
		hz: 0,
		conf: 0
	};
	const left = freq[bestI - 1];
	const right = freq[bestI + 1];
	const denom = left - 2 * best + right;
	const shift = denom === 0 ? 0 : .5 * (left - right) / denom;
	return {
		hz: (bestI + clamp(shift, -.5, .5)) * hzPer,
		conf
	};
}
function dissonance(chroma) {
	let d = 0;
	for (let i = 0; i < 12; i += 1) {
		d += chroma[i] * chroma[(i + 1) % 12];
		d += chroma[i] * chroma[(i + 6) % 12] * .7;
	}
	return clamp(d * 8, 0, 1);
}
var DEFAULT_YAW = -.62;
var DEFAULT_PITCH = .38;
var LIGHT = normalize(.22, .84, .48);
var STONE = [
	176,
	166,
	154
];
var MAJOR = [
	228,
	190,
	142
];
var MINOR = [
	142,
	156,
	196
];
var LIMBIC_MAJOR = [
	214,
	160,
	142
];
var LIMBIC_MINOR = [
	132,
	122,
	176
];
var ROSE = [
	196,
	104,
	102
];
var GOLD = [
	228,
	176,
	74
];
var NE = [
	142,
	214,
	206
];
var AUD = [
	126,
	186,
	170
];
var MOTOR = [
	206,
	136,
	88
];
var MEM = [
	210,
	196,
	226
];
var OCC = [
	176,
	164,
	204
];
var PAPER = [
	236,
	228,
	214
];
var pool = Array.from({ length: 16e3 }, () => ({
	x: 0,
	y: 0,
	depth: 0,
	r: 0,
	g: 0,
	b: 0,
	a: 0,
	rad: 0
}));
var order = new Array(pool.length);
function drawBrain(canvas, drive, view) {
	const cssW = canvas.clientWidth;
	const cssH = canvas.clientHeight;
	if (cssW < 2 || cssH < 2) return;
	const dpr = Math.min(window.devicePixelRatio || 1, 1.6);
	let bw = Math.max(2, Math.floor(cssW * dpr));
	let bh = Math.max(2, Math.floor(cssH * dpr));
	const longest = Math.max(bw, bh);
	if (longest > 1400) {
		const s = 1400 / longest;
		bw = Math.floor(bw * s);
		bh = Math.floor(bh * s);
	}
	if (canvas.width !== bw || canvas.height !== bh) {
		canvas.width = bw;
		canvas.height = bh;
	}
	const ctx = canvas.getContext("2d", {
		alpha: false,
		willReadFrequently: true
	});
	if (!ctx) return;
	const scale = bw / cssW;
	const insetTop = Math.max(108, cssH * .2) * scale;
	const insetSide = 18 * scale;
	const insetBottom = 16 * scale;
	const availW = bw - insetSide * 2;
	const availH = bh - insetTop - insetBottom;
	const viewCx = bw / 2;
	const viewCy = insetTop + availH / 2;
	const fit = Math.min(availW * .46, availH * .5) * view.zoom;
	ctx.setTransform(1, 0, 0, 1, 0, 0);
	const wash = ctx.createRadialGradient(viewCx, viewCy - availH * .06, fit * .15, viewCx, viewCy, Math.max(bw, bh) * .62);
	wash.addColorStop(0, "#17171d");
	wash.addColorStop(.55, "#101014");
	wash.addColorStop(1, "#09090c");
	ctx.fillStyle = wash;
	ctx.fillRect(0, 0, bw, bh);
	const img = ctx.getImageData(0, 0, bw, bh);
	const data = img.data;
	const points = getBrain();
	let n = 0;
	for (let i = 0; i < points.length; i += 1) {
		const p = points[i];
		const placed = place(p, drive, view.reducedMotion);
		const proj = project(placed.x, placed.y, placed.z, view.yaw, view.pitch);
		const stamp = pool[n];
		if (!stamp) break;
		const look = colorize(p, drive, proj.z);
		stamp.x = viewCx + proj.x * fit;
		stamp.y = viewCy - proj.y * fit;
		stamp.depth = proj.z + (p.tract === "none" ? 0 : .08);
		stamp.r = look.r;
		stamp.g = look.g;
		stamp.b = look.b;
		stamp.a = look.a;
		stamp.rad = look.rad * (fit / 300) * proj.p;
		n += 1;
	}
	for (const syn of drive.synapses) n = stampSynapse(syn, n, drive, view, fit, viewCx, viewCy);
	const count = Math.min(n, pool.length);
	for (let i = 0; i < count; i += 1) order[i] = i;
	const slice = order.slice(0, count);
	slice.sort((a, b) => pool[a].depth - pool[b].depth);
	for (let i = 0; i < count; i += 1) {
		const s = pool[slice[i]];
		if (s.a < .04 || s.rad < .4) continue;
		blot(data, bw, bh, s.x, s.y, s.rad, s.r, s.g, s.b, s.a);
	}
	ctx.putImageData(img, 0, 0);
	if (view.showLabels) drawLabels(ctx, view, fit, viewCx, viewCy, scale);
}
function place(p, drive, reduced) {
	if (reduced) return {
		x: p.x,
		y: p.y,
		z: p.z
	};
	const limbic = p.region === "pfc" || p.region === "amygdala" || p.region === "hippocampus";
	const amp = limbic ? .012 + Math.abs(drive.modeSlow) * .008 : .0035;
	const speed = limbic ? .42 + drive.harmonic * 1.1 : .28;
	const wob = Math.sin(drive.time * speed + p.phase * Math.PI * 2) * amp * (drive.playing ? 1 : .4);
	return {
		x: p.x + p.nx * wob,
		y: p.y + p.ny * wob,
		z: p.z + p.nz * wob
	};
}
function project(x, y, z, yaw, pitch) {
	const X = x;
	const Y = y - .06;
	const Z = z;
	const cy = Math.cos(yaw);
	const sy = Math.sin(yaw);
	const x1 = X * cy + Z * sy;
	const z1 = -X * sy + Z * cy;
	const cp = Math.cos(pitch);
	const sp = Math.sin(pitch);
	const y2 = Y * cp - z1 * sp;
	const z2 = Y * sp + z1 * cp;
	const persp = 2.35 / (2.6 - z2);
	return {
		x: x1 * persp,
		y: y2 * persp,
		z: z2,
		p: persp
	};
}
function colorize(p, drive, depth) {
	let tone = (.38 + .62 * clamp(p.nx * LIGHT[0] + p.ny * LIGHT[1] + p.nz * LIGHT[2], 0, 1)) * (.4 + .6 * p.fold) * (.68 + .32 * p.shell);
	const front = clamp((depth + .4) / 1.3, 0, 1);
	tone *= .78 + .22 * front;
	let hot = STONE;
	let amt = 0;
	let rad = (p.shell > .78 ? 2.15 : 1.35) * (.78 + .35 * p.fold);
	let alpha = .78;
	if (p.tract === "dopamine") {
		const head = drive.time * .33 % 1;
		const bolus = Math.exp(-((p.u - head) ** 2) / .02) * drive.dopamine;
		amt = clamp(.22 + drive.dopamine * .75 + bolus);
		hot = GOLD;
		alpha = .42 + amt * .58;
		rad = 1.85 + bolus * 1.4;
	} else if (p.tract === "norepinephrine") {
		amt = clamp(.16 + drive.norepinephrine * .95);
		hot = NE;
		alpha = .36 + amt * .64;
		rad = 1.7;
	} else if (p.tract === "memory") {
		amt = clamp(.14 + Math.max(drive.memory, drive.auditory * .45));
		hot = MEM;
		alpha = .34 + amt * .62;
		rad = 1.65;
	} else if (p.tract === "motor") {
		amt = clamp(.16 + Math.max(drive.beat, drive.bass * .5));
		hot = MOTOR;
		alpha = .36 + amt * .64;
		rad = 1.65 + drive.beat * .6;
	} else if (p.tract === "callosum") {
		amt = clamp(.2 + drive.energy * .45);
		hot = PAPER;
		alpha = .4 + amt * .4;
		rad = 1.45;
	} else {
		const painted = regionPaint(p, drive);
		hot = painted.hot;
		amt = painted.amt;
		rad *= painted.rad;
		if (isCortex(p.region) && drive.norepinephrine > 0) hot = mixRgb(hot, NE, drive.norepinephrine * (p.receptor === 2 ? .55 : .12));
	}
	if (p.receptor === 1 && p.tract === "none") {
		const pulse = drive.dopamine * (.5 + .5 * Math.sin(drive.time * 6.5 + p.phase * 11) ** 2);
		amt = Math.max(amt, pulse);
		hot = mixRgb(hot, GOLD, .35 + pulse * .65);
		rad *= 1 + pulse * .9;
		alpha = Math.max(alpha, .45 + pulse * .55);
	} else if (p.receptor === 2 && p.tract === "none") {
		const gate = hash01(p.id * 19 + Math.floor(drive.time * 8));
		const pulse = drive.norepinephrine * (gate > .4 ? 1 : .15);
		amt = Math.max(amt, pulse);
		hot = mixRgb(hot, NE, .4 + pulse * .6);
		rad *= 1 + pulse * .75;
	}
	if (p.region === "pfc" && drive.chordFlash > .02) {
		hot = mixRgb(hot, PAPER, drive.chordFlash * (.35 + .4 * p.fold));
		amt = Math.max(amt, drive.chordFlash);
	}
	const k = clamp(amt, 0, 1);
	const r = (STONE[0] + (hot[0] - STONE[0]) * k) * tone;
	const g = (STONE[1] + (hot[1] - STONE[1]) * k) * tone;
	const b = (STONE[2] + (hot[2] - STONE[2]) * k) * tone;
	if (!drive.playing) rad *= 1 + Math.sin(drive.time * .75 + p.phase * 6.2) * .035;
	return {
		r: clamp(r, 0, 255),
		g: clamp(g, 0, 255),
		b: clamp(b, 0, 255),
		a: clamp(alpha, 0, 1),
		rad
	};
}
function regionPaint(p, drive) {
	const playing = drive.playing;
	switch (p.region) {
		case "pfc": {
			const tide = Math.sin(drive.time * (.4 + drive.harmonic * .8) + p.phase * 6.2 + p.x * 2.4);
			return {
				hot: mixRgb(MINOR, MAJOR, clamp(drive.modeFast * .5 + .5 + tide * .07, 0, 1)),
				amt: playing ? clamp(.42 + .58 * Math.max(drive.harmonic, drive.chordFlash, Math.abs(drive.modeFast))) : 0,
				rad: 1
			};
		}
		case "amygdala":
		case "hippocampus": {
			const tide = Math.sin(drive.time * .3 + p.phase * 5 + p.y * 3);
			let hot = mixRgb(LIMBIC_MINOR, LIMBIC_MAJOR, clamp(drive.modeSlow * .5 + .5 + tide * .12, 0, 1));
			hot = mixRgb(hot, ROSE, drive.tension * .7);
			const memoryBoost = p.region === "hippocampus" ? drive.memory : 0;
			return {
				hot: memoryBoost > .2 ? mixRgb(hot, MEM, memoryBoost * .6) : hot,
				amt: playing ? clamp(.38 + .62 * Math.max(Math.abs(drive.modeSlow), drive.tension, memoryBoost)) : .12,
				rad: 1 + memoryBoost * .25
			};
		}
		case "temporal": {
			const place = clamp((p.y + .42) / .52, 0, 1);
			const band = Math.exp(-((place - drive.pitchNorm) ** 2) / .016);
			return {
				hot: AUD,
				amt: playing ? clamp(drive.auditory * (.3 + band * drive.pitchConf * 1.15)) : 0,
				rad: 1 + (playing ? band * drive.pitchConf * .28 : 0)
			};
		}
		case "motor":
		case "cerebellum": return {
			hot: MOTOR,
			amt: playing ? clamp(.18 + drive.beat * .95 + drive.bass * .28) : 0,
			rad: 1 + drive.beat * .42
		};
		case "occipital": return {
			hot: OCC,
			amt: playing ? clamp(drive.highs * 1.15) : 0,
			rad: 1 + drive.highs * .2
		};
		case "nacc":
		case "vta": return {
			hot: GOLD,
			amt: clamp(.34 + drive.dopamine * .85),
			rad: 1.25 + drive.dopamine * .7
		};
		case "lc": return {
			hot: NE,
			amt: clamp(.36 + drive.norepinephrine * .8),
			rad: 1.2 + drive.norepinephrine * .65
		};
		case "brainstem": return {
			hot: mixRgb(STONE, NE, .35),
			amt: playing ? clamp(drive.norepinephrine * .7 + drive.bass * .2) : .08,
			rad: 1
		};
		default: return {
			hot: STONE,
			amt: playing ? clamp(drive.energy * .28) : 0,
			rad: 1
		};
	}
}
function isCortex(region) {
	return region === "pfc" || region === "motor" || region === "parietal" || region === "occipital" || region === "temporal" || region === "cerebellum";
}
function stampSynapse(syn, n, drive, view, fit, viewCx, viewCy) {
	const count = 8 + Math.round(syn.strength * 16);
	for (let i = 0; i < count; i += 1) {
		const t = count === 1 ? 1 : i / (count - 1);
		if (t > syn.reveal + .02) break;
		const o = 1 - t;
		const proj = project(o * o * syn.ax + 2 * o * t * syn.cx + t * t * syn.bx, o * o * syn.ay + 2 * o * t * syn.cy + t * t * syn.by, o * o * syn.az + 2 * o * t * syn.cz + t * t * syn.bz, view.yaw, view.pitch);
		const stamp = pool[n];
		if (!stamp) return n;
		const grow = t > syn.reveal ? .2 : 1;
		const head = t > syn.reveal - .12 ? 1 : .75;
		stamp.x = viewCx + proj.x * fit;
		stamp.y = viewCy - proj.y * fit;
		stamp.depth = proj.z + .22;
		const mix = .45 + syn.strength * .55;
		stamp.r = lerp(210, 232, mix) * head;
		stamp.g = lerp(200, 214, mix) * head;
		stamp.b = lerp(190, 236, mix) * head;
		stamp.a = (.45 + syn.strength * .5) * grow;
		stamp.rad = (1.7 + syn.strength * 1.5) * (fit / 300) * proj.p * (i === count - 1 ? 1.35 : 1);
		n += 1;
	}
	return n;
}
function drawLabels(ctx, view, fit, viewCx, viewCy, scale) {
	ctx.save();
	ctx.font = `500 ${Math.max(11, Math.round(12 * scale))}px Outfit, sans-serif`;
	ctx.textBaseline = "middle";
	ctx.fillStyle = "rgba(243, 236, 223, 0.72)";
	for (const label of LABEL_ANCHORS) {
		const proj = project(label.at[0], label.at[1], label.at[2], view.yaw, view.pitch);
		const sx = viewCx + proj.x * fit;
		const sy = viewCy - proj.y * fit;
		const dx = sx - viewCx;
		const dy = sy - viewCy;
		const m = Math.hypot(dx, dy) || 1;
		const lx = sx + dx / m * 34 * scale;
		const ly = sy + dy / m * 26 * scale;
		ctx.textAlign = dx > 8 ? "left" : dx < -8 ? "right" : "center";
		ctx.fillText(label.text, lx, ly);
	}
	ctx.restore();
}
function blot(data, w, h, x, y, rad, cr, cg, cb, ca) {
	const r = Math.max(.8, Math.min(rad, 6.5));
	const r2 = r * r;
	const x0 = Math.round(x);
	const y0 = Math.round(y);
	const ri = Math.ceil(r);
	for (let dy = -ri; dy <= ri; dy += 1) {
		const py = y0 + dy;
		if (py < 0 || py >= h) continue;
		const row = py * w;
		for (let dx = -ri; dx <= ri; dx += 1) {
			const px = x0 + dx;
			if (px < 0 || px >= w) continue;
			const ddx = px + .5 - x;
			const ddy = py + .5 - y;
			const d2 = ddx * ddx + ddy * ddy;
			if (d2 > r2) continue;
			const fall = 1 - d2 / r2;
			const cover = ca * fall * fall;
			const i = (row + px) * 4;
			const inv = 1 - cover;
			const core = .72 + .28 * fall;
			data[i] = data[i] * inv + cr * core * cover;
			data[i + 1] = data[i + 1] * inv + cg * core * cover;
			data[i + 2] = data[i + 2] * inv + cb * core * cover;
		}
	}
}
function mixRgb(a, b, t) {
	const k = clamp(t, 0, 1);
	return [
		a[0] + (b[0] - a[0]) * k,
		a[1] + (b[1] - a[1]) * k,
		a[2] + (b[2] - a[2]) * k
	];
}
function normalize(x, y, z) {
	const m = Math.hypot(x, y, z) || 1;
	return [
		x / m,
		y / m,
		z / m
	];
}
var SYSTEMS = [
	{
		key: "pfc",
		name: "Prefrontal cortex",
		hears: "Chord changes. Major warms it, minor cools it.",
		swatch: "bg-pfc"
	},
	{
		key: "limbic",
		name: "Limbic system",
		hears: "Harmonic mood, drifting in a slow color tide.",
		swatch: "bg-limbic"
	},
	{
		key: "dopamine",
		name: "Dopamine",
		hears: "Rising pitch, a quicker tempo, the drop.",
		swatch: "bg-da"
	},
	{
		key: "norepinephrine",
		name: "Norepinephrine",
		hears: "Sudden hits and leaps in pitch.",
		swatch: "bg-ne"
	},
	{
		key: "auditory",
		name: "Auditory cortex",
		hears: "Where the melody sits, low notes to high.",
		swatch: "bg-auditory"
	},
	{
		key: "motor",
		name: "Motor and cerebellum",
		hears: "The beat, locked to tempo.",
		swatch: "bg-motor"
	},
	{
		key: "memory",
		name: "Hippocampus",
		hears: "A motif returns, and neurons link.",
		swatch: "bg-memory"
	}
];
function statusLine(readout) {
	if (readout.source === "study") return "Listening to the study";
	if (readout.source === "mic") return "Listening through the mic";
	if (readout.source === "file") return readout.fileName || "Playing a track";
	return "At rest";
}
function CerebraStage() {
	const canvasRef = (0, import_react.useRef)(null);
	const fileRef = (0, import_react.useRef)(null);
	const sessionRef = (0, import_react.useRef)(null);
	const bridgeRef = (0, import_react.useRef)(null);
	if (!bridgeRef.current) bridgeRef.current = {
		readout: IDLE_READOUT,
		listeners: /* @__PURE__ */ new Set()
	};
	const yawRef = (0, import_react.useRef)(DEFAULT_YAW);
	const pitchRef = (0, import_react.useRef)(DEFAULT_PITCH);
	const zoomRef = (0, import_react.useRef)(1);
	const dragRef = (0, import_react.useRef)(null);
	const dragDepth = (0, import_react.useRef)(0);
	const readout = (0, import_react.useSyncExternalStore)((notify) => {
		const bridge = bridgeRef.current;
		if (!bridge) return () => {};
		bridge.listeners.add(notify);
		return () => bridge.listeners.delete(notify);
	}, () => bridgeRef.current?.readout ?? IDLE_READOUT, () => IDLE_READOUT);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [dragOver, setDragOver] = (0, import_react.useState)(false);
	const [volume, setVolume] = (0, import_react.useState)(.85);
	const [mounted, setMounted] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		const bridge = bridgeRef.current;
		if (!canvas || !bridge) return;
		const session = new AudioSession();
		sessionRef.current = session;
		setVolume(session.getVolume());
		const unsub = session.subscribe(() => {
			bridge.readout = session.getReadout();
			bridge.listeners.forEach((fn) => fn());
		});
		const reduced = window.matchMedia("(prefers-reduced-motion: reduce)");
		let frame = 0;
		let last = performance.now();
		const loop = (now) => {
			const dt = Math.min(.05, (now - last) / 1e3);
			last = now;
			session.tick(dt);
			drawBrain(canvas, session.drive, {
				yaw: yawRef.current,
				pitch: pitchRef.current,
				zoom: zoomRef.current,
				reducedMotion: reduced.matches,
				showLabels: false
			});
			frame = requestAnimationFrame(loop);
		};
		frame = requestAnimationFrame(loop);
		const onWheel = (event) => {
			event.preventDefault();
			zoomRef.current = clamp(zoomRef.current * Math.exp(-event.deltaY * .0011), .65, 1.85);
		};
		canvas.addEventListener("wheel", onWheel, { passive: false });
		const onVisibility = () => {
			if (document.visibilityState !== "visible") return;
			const ctx = sessionRef.current;
			if (!ctx) return;
			if (ctx.getReadout().source !== "idle") ctx.nudge();
		};
		document.addEventListener("visibilitychange", onVisibility);
		const debug = {
			snapshot: () => session.getReadout(),
			drive: () => ({
				dopamine: session.drive.dopamine,
				norepinephrine: session.drive.norepinephrine,
				modeFast: session.drive.modeFast,
				modeSlow: session.drive.modeSlow,
				auditory: session.drive.auditory,
				beat: session.drive.beat,
				memory: session.drive.memory,
				links: session.drive.synapses.length,
				playing: session.drive.playing
			})
		};
		window.__cerebra = debug;
		return () => {
			cancelAnimationFrame(frame);
			canvas.removeEventListener("wheel", onWheel);
			document.removeEventListener("visibilitychange", onVisibility);
			unsub();
			session.dispose();
			sessionRef.current = null;
			if (window.__cerebra === debug) delete window.__cerebra;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		setMounted(true);
	}, []);
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			if (event.code !== "Space") return;
			if (event.target instanceof HTMLInputElement || event.target instanceof HTMLTextAreaElement) return;
			event.preventDefault();
			const session = sessionRef.current;
			if (!session || busy) return;
			if (session.getReadout().source === "idle") session.startStudy();
			else session.stop();
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [busy]);
	const playing = readout.source !== "idle";
	async function onStudy() {
		const session = sessionRef.current;
		if (!session) return;
		setBusy(true);
		try {
			if (session.getReadout().source === "study") await session.stop();
			else await session.startStudy();
		} finally {
			setBusy(false);
		}
	}
	async function onMic() {
		const session = sessionRef.current;
		if (!session) return;
		setBusy(true);
		try {
			if (session.getReadout().source === "mic") await session.stop();
			else await session.startMic();
		} finally {
			setBusy(false);
		}
	}
	async function onFile(file) {
		const session = sessionRef.current;
		if (!session || !file) return;
		setBusy(true);
		try {
			await session.startFile(file);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex h-dvh flex-col bg-bg text-fg lg:flex-row",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative min-h-0 flex-1",
			onDragEnter: (event) => {
				event.preventDefault();
				dragDepth.current += 1;
				setDragOver(true);
			},
			onDragOver: (event) => event.preventDefault(),
			onDragLeave: () => {
				dragDepth.current -= 1;
				if (dragDepth.current <= 0) {
					dragDepth.current = 0;
					setDragOver(false);
				}
			},
			onDrop: (event) => {
				event.preventDefault();
				dragDepth.current = 0;
				setDragOver(false);
				const file = event.dataTransfer.files?.[0];
				onFile(file);
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
					ref: canvasRef,
					className: "cerebra-view absolute inset-0 h-full w-full",
					"aria-hidden": "true",
					onPointerDown: (event) => {
						dragRef.current = {
							id: event.pointerId,
							x: event.clientX,
							y: event.clientY
						};
						event.currentTarget.setPointerCapture(event.pointerId);
					},
					onPointerMove: (event) => {
						const drag = dragRef.current;
						if (!drag || drag.id !== event.pointerId) return;
						const dx = event.clientX - drag.x;
						const dy = event.clientY - drag.y;
						drag.x = event.clientX;
						drag.y = event.clientY;
						yawRef.current -= dx * .006;
						pitchRef.current = clamp(pitchRef.current + dy * .0045, -.35, 1.05);
					},
					onPointerUp: (event) => {
						if (dragRef.current?.id === event.pointerId) dragRef.current = null;
					},
					onPointerCancel: () => {
						dragRef.current = null;
					},
					onDoubleClick: () => {
						yawRef.current = DEFAULT_YAW;
						pitchRef.current = DEFAULT_PITCH;
						zoomRef.current = 1;
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between gap-4 p-4 sm:p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-widest text-muted uppercase",
							children: "Audio anatomy"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-4xl leading-none text-fg sm:text-5xl",
							children: "Cerebra"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 hidden max-w-xs text-sm text-muted sm:block",
							children: "Pitch, pulse, and memory, drawn as a brain."
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "hidden max-w-56 text-right text-sm text-fg sm:block",
						children: statusLine(readout)
					})]
				}),
				dragOver ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pointer-events-none absolute inset-4 flex items-center justify-center rounded-xl border border-dashed border-accent sm:inset-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "bg-bg px-4 py-2 text-sm text-fg",
						children: "Drop a recording"
					})
				}) : null
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "cerebra-panel flex h-[52dvh] min-h-0 w-full shrink-0 flex-col overflow-hidden border-t border-line bg-surface lg:h-full lg:w-96 lg:border-t-0 lg:border-l",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "grid shrink-0 grid-cols-4 gap-2 px-4 pt-4 lg:px-5 lg:pt-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Bpm",
							value: readout.bpm
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Key",
							value: readout.key
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Chord",
							value: readout.chord
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Links",
							value: String(readout.links)
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 flex min-h-0 flex-1 flex-col gap-3 overflow-y-auto px-4 lg:px-5",
					children: SYSTEMS.map((system) => {
						const level = readout.levels[system.key];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "grid grid-cols-[1fr_auto] items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "flex items-center gap-2 text-sm text-fg",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `size-2 shrink-0 rounded-full ${system.swatch}`,
										"aria-hidden": "true"
									}), system.name]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-0.5 text-xs leading-snug text-muted",
									children: system.hears
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								role: "meter",
								"aria-valuemin": 0,
								"aria-valuemax": 100,
								"aria-valuenow": Math.round(level * 100),
								"aria-label": `${system.name} activity`,
								className: "h-1 w-14 overflow-hidden rounded-full bg-line",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `h-full origin-left ${system.swatch} motion-reduce:transition-none`,
									style: { transform: `scaleX(${Math.max(.06, level)})` }
								})
							})]
						}, system.key);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 shrink-0 space-y-3 border-t border-line px-4 pt-3 lg:px-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "col-span-2 inline-flex h-12 items-center justify-center gap-2 rounded-xl bg-accent px-4 text-sm text-bg focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent disabled:opacity-50",
									onClick: () => void onStudy(),
									disabled: busy,
									"aria-pressed": readout.source === "study",
									children: [playing && readout.source === "study" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, {
										className: "size-4",
										"aria-hidden": "true"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
										className: "size-4",
										"aria-hidden": "true"
									}), readout.source === "study" ? "Stop study" : "Play study"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "inline-flex h-12 items-center justify-center gap-2 rounded-xl border border-line bg-bg px-3 text-sm text-fg focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent disabled:opacity-50",
									onClick: () => void onMic(),
									disabled: busy,
									"aria-pressed": readout.source === "mic",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, {
										className: "size-4",
										"aria-hidden": "true"
									}), readout.source === "mic" ? "Stop mic" : "Microphone"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "inline-flex h-12 items-center justify-center gap-2 rounded-xl border border-line bg-bg px-3 text-sm text-fg focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent disabled:opacity-50",
									onClick: () => fileRef.current?.click(),
									disabled: busy,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, {
										className: "size-4",
										"aria-hidden": "true"
									}), "Upload"]
								}),
								mounted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									ref: fileRef,
									className: "sr-only",
									type: "file",
									accept: "audio/*,.mp3,.wav,.ogg,.m4a,.aac,.flac,.webm",
									onChange: (event) => {
										const file = event.target.files?.[0];
										event.target.value = "";
										onFile(file);
									}
								}) : null
							]
						}),
						playing && readout.source !== "mic" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center justify-between gap-3 text-xs text-muted",
							children: ["Volume", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "w-28",
								type: "range",
								min: 0,
								max: 1,
								step: .01,
								value: volume,
								onChange: (event) => {
									const next = Number(event.target.value);
									setVolume(next);
									sessionRef.current?.setVolume(next);
								}
							})]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: readout.message ? "text-sm text-limbic" : "text-sm text-muted",
							children: readout.message || (playing ? "Drag the brain to turn it. A repeated phrase grows a new link." : "Play the study, open the microphone, or drop a track on the brain.")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "lg:hidden",
								children: "Drag to turn. Double-tap to reset."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden lg:inline",
								children: "Drag to turn. Scroll to zoom. Double-click to reset. Space plays the study."
							})]
						})
					]
				})
			]
		})]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-w-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs tracking-widest text-muted uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "truncate font-display text-lg leading-tight text-fg",
			title: value,
			children: value
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CerebraStage, {});
}
//#endregion
export { Home as component };
